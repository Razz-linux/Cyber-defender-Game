import React, { useCallback, useState } from 'react';
import { SplashScreen } from './pages/SplashScreen';
import { MainMenu } from './pages/MainMenu';
import { InstructionsScreen } from './pages/InstructionsScreen';
import { SettingsScreen } from './pages/SettingsScreen';
import { LevelSelectScreen } from './pages/LevelSelectScreen';
import { MissionBriefScreen } from './pages/MissionBriefScreen';
import { GameContainer } from './pages/GameContainer';
import { ResultScreen } from './pages/ResultScreen';
import { CertificateScreen } from './pages/CertificateScreen';
import type { LevelResult, Screen } from './types';
import { SaveManager } from './services/SaveManager';

export const App: React.FC = () => {
  const [screen, setScreen] = useState<Screen>('splash');
  const [selectedLevel, setSelectedLevel] = useState<number>(1);
  const [lastResult, setLastResult] = useState<LevelResult | null>(null);

  const goSelect = useCallback((level: number) => {
    if (level === 99) {
      setScreen('certificate');
      return;
    }
    setSelectedLevel(level);
    setScreen('brief');
  }, []);

  const onLevelComplete = useCallback((result: LevelResult) => {
    setLastResult(result);
    setScreen('result');
  }, []);

  const goNextOrCert = useCallback(() => {
    if (!lastResult) return;
    if (lastResult.level < 3) {
      setSelectedLevel(lastResult.level + 1);
      setScreen('brief');
    } else {
      // certificate only awarded if all 3 completed
      const data = SaveManager.loadProgress();
      if (data.certificateEarned) {
        setScreen('certificate');
      } else {
        setScreen('levelSelect');
      }
    }
  }, [lastResult]);

  switch (screen) {
    case 'splash':
      return <SplashScreen onComplete={() => setScreen('menu')} />;
    case 'menu':
      return <MainMenu onNavigate={s => setScreen(s)} />;
    case 'instructions':
      return <InstructionsScreen onBack={() => setScreen('menu')} />;
    case 'settings':
      return <SettingsScreen onBack={() => setScreen('menu')} />;
    case 'levelSelect':
      return (
        <LevelSelectScreen
          onSelect={goSelect}
          onBack={() => setScreen('menu')}
        />
      );
    case 'brief':
      return (
        <MissionBriefScreen
          level={selectedLevel}
          onAccept={() => setScreen('game')}
          onCancel={() => setScreen('levelSelect')}
        />
      );
    case 'game':
      return (
        <GameContainer
          level={selectedLevel}
          onComplete={onLevelComplete}
          onAbort={() => setScreen('levelSelect')}
        />
      );
    case 'result':
      if (!lastResult) {
        setScreen('levelSelect');
        return null;
      }
      return (
        <ResultScreen
          result={lastResult}
          onNext={goNextOrCert}
          onRetry={() => setScreen('brief')}
          onHome={() => setScreen('levelSelect')}
        />
      );
    case 'certificate':
      return <CertificateScreen onHome={() => setScreen('menu')} />;
    default:
      return <MainMenu onNavigate={s => setScreen(s)} />;
  }
};
