import React from 'react';
import { Button } from '../components/Button';
import { StarRating } from '../components/StarRating';
import { SaveManager } from '../services/SaveManager';
import { useSaveManager } from '../hooks/useSaveManager';

interface LevelSelectScreenProps {
  onSelect: (level: number) => void;
  onBack: () => void;
}

const LEVELS = [
  { id: 1, title: 'PHISHING DETECTION', topic: 'Email & Social Engineering', icon: '📧' },
  { id: 2, title: 'PASSWORD SECURITY', topic: 'Credentials & Hygiene', icon: '🔐' },
  { id: 3, title: 'MALWARE ANALYSIS', topic: 'File System Forensics', icon: '🦠' }
];

export const LevelSelectScreen: React.FC<LevelSelectScreenProps> = ({ onSelect, onBack }) => {
  const { data } = useSaveManager();

  return (
    <div className="min-h-screen bg-cyber-bg animate-fade-in relative overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-30" />
      <div className="relative z-10 max-w-6xl mx-auto p-6 md:p-10">
        <div className="relative mb-2 overflow-hidden">
          <h1 className="font-display text-3xl md:text-4xl tracking-widest">SELECT MISSION</h1>
          <div className="absolute left-0 right-0 top-1/2 h-px bg-gradient-to-r from-transparent via-cyber-success to-transparent animate-scan" />
        </div>
        <p className="text-slate-400 text-sm mb-8">Choose your training operation, Recruit.</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {LEVELS.map(l => {
            const unlocked = SaveManager.isLevelUnlocked(l.id);
            const completed = data.completedLevels.includes(l.id);
            const stars = data.levelStars[String(l.id)] || 0;
            const best = data.bestScores[String(l.id)] || 0;
            return (
              <div
                key={l.id}
                className={`relative rounded-xl border bg-cyber-card transition-all ${
                  unlocked
                    ? 'border-cyber-primary/40 card-lift hover:border-cyber-primary'
                    : 'border-cyber-border opacity-60'
                }`}
                style={
                  unlocked
                    ? { boxShadow: '0 0 25px rgba(37,99,235,0.15)' }
                    : undefined
                }
              >
                <div className="p-6 flex flex-col h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="font-mono text-xs text-cyber-primary tracking-widest mb-1">
                        MISSION {String(l.id).padStart(2, '0')}
                      </div>
                      <div className="font-display text-lg tracking-wider">{l.title}</div>
                      <div className="text-xs text-slate-400 mt-1">{l.topic}</div>
                    </div>
                    <div className="text-4xl">{l.icon}</div>
                  </div>

                  <div className="flex-1 flex flex-col items-center justify-center my-4 gap-3">
                    <StarRating value={stars} size={26} />
                    <div className="text-xs font-mono text-slate-400">
                      BEST SCORE:{' '}
                      <span className="text-cyber-success font-bold">{best}</span> / 100
                    </div>
                  </div>

                  <div
                    className={`text-center text-xs font-display tracking-widest py-2 rounded-md mb-4 ${
                      !unlocked
                        ? 'bg-cyber-disabled/40 text-slate-500'
                        : completed
                        ? 'bg-cyber-success/20 text-cyber-success'
                        : 'bg-cyber-primary/20 text-cyber-primary'
                    }`}
                  >
                    {!unlocked ? '🔒 LOCKED' : completed ? '✓ COMPLETED' : '▶ AVAILABLE'}
                  </div>

                  <Button
                    variant={completed ? 'success' : 'primary'}
                    full
                    disabled={!unlocked}
                    onClick={() => onSelect(l.id)}
                  >
                    {!unlocked ? 'LOCKED' : completed ? 'REPLAY MISSION' : 'BEGIN MISSION'}
                  </Button>
                </div>

                {!unlocked && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none rounded-xl">
                    <div className="text-6xl opacity-40">🔒</div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {data.certificateEarned && (
          <div className="mt-8 text-center">
            <Button variant="warning" onClick={() => onSelect(99)}>
              🏆 View Certification
            </Button>
          </div>
        )}

        <div className="mt-8">
          <Button variant="ghost" onClick={onBack}>
            ← Return to Base
          </Button>
        </div>
      </div>
    </div>
  );
};
