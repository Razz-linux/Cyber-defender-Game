import React, { useEffect, useRef, useState } from 'react';
import Phaser from 'phaser';
import { createPhaserGame } from '../game/PhaserGame';
import { EventBus } from '../game/EventBus';
import { useGameState } from '../hooks/useGameState';
import { Button } from '../components/Button';
import { Modal } from '../components/Modal';
import type { LevelResult } from '../types';

interface GameContainerProps {
  level: number;
  onComplete: (result: LevelResult) => void;
  onAbort: () => void;
}

export const GameContainer: React.FC<GameContainerProps> = ({ level, onComplete, onAbort }) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);
  const { score, hintsRemaining } = useGameState();
  const [showAbort, setShowAbort] = useState(false);

  useEffect(() => {
    if (!hostRef.current) return;
    gameRef.current = createPhaserGame(hostRef.current, level);

    const handleComplete = (result: LevelResult) => {
      onComplete(result);
    };
    EventBus.on('levelComplete', handleComplete);

    return () => {
      EventBus.off('levelComplete', handleComplete);
      gameRef.current?.destroy(true);
      gameRef.current = null;
    };
  }, [level, onComplete]);

  const titles: Record<number, string> = {
    1: 'PHISHING DETECTION',
    2: 'PASSWORD SECURITY',
    3: 'MALWARE ANALYSIS'
  };

  return (
    <div className="min-h-screen bg-cyber-bg flex flex-col animate-fade-in">
      <header className="flex items-center justify-between px-6 py-3 bg-cyber-card border-b border-cyber-border">
        <div className="flex items-center gap-4">
          <div className="w-2.5 h-2.5 rounded-full bg-cyber-danger animate-pulse" />
          <div className="font-display text-sm tracking-widest">
            MISSION {String(level).padStart(2, '0')} — {titles[level]}
          </div>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono">
          <div>
            SCORE: <span className="text-cyber-success font-bold">{score}</span>
          </div>
          <div>
            HINTS: <span className="text-cyber-primary font-bold">{hintsRemaining}</span>
          </div>
          <Button variant="primary" size="sm" onClick={() => EventBus.emit('hintRequest')}>
            💡 Use Hint
          </Button>
          <Button variant="danger" size="sm" onClick={() => setShowAbort(true)}>
            ✕ Abort
          </Button>
        </div>
      </header>

      <div ref={hostRef} className="phaser-host flex-1 flex items-center justify-center p-3" />

      <Modal
        open={showAbort}
        title="ABORT MISSION?"
        message="Your current progress in this mission will be lost. Are you sure?"
        variant="danger"
        confirmLabel="Abort"
        onConfirm={onAbort}
        onCancel={() => setShowAbort(false)}
      />
    </div>
  );
};
