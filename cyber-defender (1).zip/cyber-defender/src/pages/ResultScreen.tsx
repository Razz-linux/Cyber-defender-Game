import React, { useEffect } from 'react';
import { Button } from '../components/Button';
import { StarRating } from '../components/StarRating';
import { ScoreCounter } from '../components/ScoreCounter';
import { SaveManager } from '../services/SaveManager';
import type { LevelResult } from '../types';

interface ResultScreenProps {
  result: LevelResult;
  onNext: () => void;
  onRetry: () => void;
  onHome: () => void;
}

const performanceLabel = (stars: number, score: number) => {
  if (stars === 3) return { text: 'EXCELLENT', color: '#22C55E' };
  if (stars === 2) return { text: 'GOOD', color: '#2563EB' };
  if (stars === 1) return { text: 'PASS', color: '#FACC15' };
  return { text: score >= 50 ? 'PASS' : 'FAILED', color: '#EF4444' };
};

export const ResultScreen: React.FC<ResultScreenProps> = ({ result, onNext, onRetry, onHome }) => {
  useEffect(() => {
    SaveManager.saveScore(result.level, result.score, result.stars);
  }, [result]);

  const perf = performanceLabel(result.stars, result.score);
  const minutes = Math.floor(result.timeTaken / 60);
  const seconds = result.timeTaken % 60;
  const hasNext = result.level < 3 && result.stars > 0;

  return (
    <div className="min-h-screen bg-cyber-bg animate-fade-in relative overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-30" />
      <div className="relative z-10 max-w-4xl mx-auto p-6 md:p-10">
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-display text-3xl md:text-4xl tracking-widest">MISSION DEBRIEF</h1>
          <div className="text-xs font-mono text-slate-400">
            MISSION {String(result.level).padStart(2, '0')} / 03
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Score panel */}
          <div className="bg-cyber-card border border-cyber-border rounded-xl p-8 text-center">
            <div className="text-xs font-mono text-slate-400 tracking-widest mb-2">FINAL SCORE</div>
            <div className="font-display text-7xl text-cyber-success font-black">
              <ScoreCounter target={result.score} />
              <span className="text-3xl text-slate-500"> / 100</span>
            </div>
            <div className="my-6 flex justify-center">
              <StarRating value={result.stars} animated size={44} />
            </div>
            <div
              className="font-display text-2xl tracking-[0.4em]"
              style={{ color: perf.color, textShadow: `0 0 20px ${perf.color}` }}
            >
              {perf.text}
            </div>
          </div>

          {/* Breakdown */}
          <div className="bg-cyber-card border border-cyber-border rounded-xl p-6">
            <h3 className="font-display tracking-widest text-cyber-primary mb-4">BREAKDOWN</h3>
            <div className="space-y-3 text-sm font-mono">
              <div className="flex justify-between border-b border-cyber-border pb-2">
                <span className="text-slate-400">Correct answers</span>
                <span className="text-cyber-success font-bold">{result.correct}</span>
              </div>
              <div className="flex justify-between border-b border-cyber-border pb-2">
                <span className="text-slate-400">Wrong answers</span>
                <span className="text-cyber-danger font-bold">{result.wrong}</span>
              </div>
              <div className="flex justify-between border-b border-cyber-border pb-2">
                <span className="text-slate-400">Hints used</span>
                <span className="text-cyber-warning font-bold">{result.hintsUsed}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Time taken</span>
                <span className="text-white font-bold">
                  {minutes}m {String(seconds).padStart(2, '0')}s
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Learning points */}
        <div className="mt-6 bg-cyber-card border border-cyber-border rounded-xl p-6">
          <h3 className="font-display tracking-widest text-cyber-primary mb-4">▌ KEY TAKEAWAYS</h3>
          <ul className="space-y-3 text-sm text-slate-200">
            {result.learningPoints.map((p, i) => (
              <li key={i} className="flex gap-3 items-start">
                <span className="text-cyber-success font-bold mt-0.5">▸</span>
                <span className="leading-relaxed">{p}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-8 flex flex-col md:flex-row gap-4 justify-end">
          <Button variant="ghost" onClick={onHome}>
            ← Return to Base
          </Button>
          <Button variant="warning" onClick={onRetry}>
            ↻ Retry Mission
          </Button>
          {hasNext && (
            <Button variant="success" size="lg" onClick={onNext}>
              ▶ Next Mission
            </Button>
          )}
          {result.level === 3 && result.stars > 0 && (
            <Button variant="success" size="lg" onClick={onNext}>
              🏆 View Certificate
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};
