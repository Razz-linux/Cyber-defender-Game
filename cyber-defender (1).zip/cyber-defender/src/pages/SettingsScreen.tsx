import React, { useState } from 'react';
import { Button } from '../components/Button';
import { Modal } from '../components/Modal';
import { SaveManager } from '../services/SaveManager';
import { AudioManager } from '../services/AudioManager';
import type { Difficulty } from '../types';

interface SettingsScreenProps {
  onBack: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ onBack }) => {
  const initial = SaveManager.loadProgress();
  const [music, setMusic] = useState(initial.settings.music);
  const [sound, setSound] = useState(initial.settings.sound);
  const [difficulty, setDifficulty] = useState<Difficulty>(initial.settings.difficulty);
  const [name, setName] = useState(initial.playerName);
  const [showReset, setShowReset] = useState(false);
  const [saved, setSaved] = useState(false);

  const Toggle: React.FC<{ on: boolean; onChange: (v: boolean) => void; label: string }> = ({ on, onChange, label }) => (
    <div className="flex items-center justify-between bg-cyber-card border border-cyber-border rounded-lg p-4">
      <span className="text-sm font-mono">{label}</span>
      <button
        onClick={() => onChange(!on)}
        className={`w-14 h-7 rounded-full relative transition-colors ${on ? 'bg-cyber-success' : 'bg-cyber-disabled'}`}
        aria-label={label}
      >
        <span
          className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${on ? 'translate-x-7' : ''}`}
        />
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-cyber-bg animate-fade-in relative">
      <div className="absolute inset-0 bg-grid opacity-30" />
      <div className="relative z-10 max-w-2xl mx-auto p-6 md:p-10">
        <h1 className="font-display text-3xl md:text-4xl tracking-widest mb-2">SYSTEM CONFIGURATION</h1>
        <p className="text-slate-400 text-sm mb-8">Adjust audio, difficulty and operator profile.</p>

        <div className="space-y-4">
          <Toggle
            on={music}
            onChange={v => {
              setMusic(v);
              AudioManager.setMusic(v);
            }}
            label="🎵 Background Music"
          />
          <Toggle
            on={sound}
            onChange={v => {
              setSound(v);
              AudioManager.setSound(v);
              if (v) AudioManager.playSFX('click');
            }}
            label="🔊 Sound Effects"
          />

          <div className="bg-cyber-card border border-cyber-border rounded-lg p-4">
            <div className="text-sm font-mono mb-3">⚡ Difficulty</div>
            <div className="grid grid-cols-3 gap-3">
              {(['easy', 'normal', 'hard'] as Difficulty[]).map(d => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={`py-2 rounded-md font-display tracking-widest text-xs transition-all ${
                    difficulty === d
                      ? 'bg-cyber-primary text-white shadow-[0_0_15px_rgba(37,99,235,0.6)]'
                      : 'bg-cyber-secondary text-slate-400 hover:bg-cyber-border'
                  }`}
                >
                  {d.toUpperCase()}
                </button>
              ))}
            </div>
            <p className="mt-3 text-xs text-slate-400">
              {difficulty === 'easy' && 'No point deductions for wrong answers.'}
              {difficulty === 'normal' && 'Standard scoring: -5 per wrong answer.'}
              {difficulty === 'hard' && 'Severe penalties (-10 per wrong) and faster timer.'}
            </p>
          </div>

          <div className="bg-cyber-card border border-cyber-border rounded-lg p-4">
            <label className="text-sm font-mono mb-2 block">👤 Operator Name</label>
            <input
              value={name}
              maxLength={20}
              onChange={e => setName(e.target.value)}
              className="w-full bg-cyber-bg border border-cyber-border rounded-md px-3 py-2 font-mono text-sm focus:outline-none focus:border-cyber-primary"
            />
          </div>
        </div>

        <div className="mt-8 flex flex-col gap-3">
          <Button
            variant="success"
            full
            onClick={() => {
              SaveManager.saveSettings({ music, sound, difficulty });
              SaveManager.savePlayerName(name);
              setSaved(true);
              setTimeout(() => setSaved(false), 1500);
            }}
          >
            💾 Save Settings
          </Button>
          {saved && <div className="text-center text-cyber-success text-sm font-mono">Settings saved ✓</div>}
          <Button variant="danger" full onClick={() => setShowReset(true)}>
            ⚠ Reset All Progress
          </Button>
          <Button variant="ghost" full onClick={onBack}>
            ← Return to Base
          </Button>
        </div>
      </div>

      <Modal
        open={showReset}
        title="RESET ALL PROGRESS?"
        message="All scores, stars, and certification will be permanently erased. This cannot be undone."
        variant="danger"
        confirmLabel="Wipe Save"
        onConfirm={() => {
          SaveManager.resetGame();
          setShowReset(false);
          setMusic(true);
          setSound(true);
          setDifficulty('normal');
          setName('Recruit');
        }}
        onCancel={() => setShowReset(false)}
      />
    </div>
  );
};
