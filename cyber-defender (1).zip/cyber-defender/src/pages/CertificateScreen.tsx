import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Button } from '../components/Button';
import { TypingText } from '../components/TypingText';
import { useSaveManager } from '../hooks/useSaveManager';

interface CertificateScreenProps {
  onHome: () => void;
}

export const CertificateScreen: React.FC<CertificateScreenProps> = ({ onHome }) => {
  const { data } = useSaveManager();
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const completionDate = useMemo(() => {
    const d = data.completionTime ? new Date(data.completionTime) : new Date();
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  }, [data.completionTime]);

  const confettiPieces = useMemo(
    () =>
      Array.from({ length: 80 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 3,
        duration: 3 + Math.random() * 3,
        color: ['#2563EB', '#22C55E', '#FACC15', '#EF4444', '#3B82F6'][Math.floor(Math.random() * 5)],
        rotate: Math.random() * 360
      })),
    []
  );

  const certText = `This certifies that ${data.playerName} has successfully completed all three missions of Cyber Defense Academy and demonstrated proficiency in Phishing Detection, Password Security, and Malware Analysis.`;

  const drawAndDownload = () => {
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = 1400;
    canvas.height = 1000;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    ctx.fillStyle = '#0B1020';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Gradient border
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, '#2563EB');
    grad.addColorStop(1, '#22C55E');
    ctx.strokeStyle = grad;
    ctx.lineWidth = 8;
    ctx.strokeRect(40, 40, canvas.width - 80, canvas.height - 80);
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#334155';
    ctx.strokeRect(70, 70, canvas.width - 140, canvas.height - 140);

    // Grid dots
    ctx.fillStyle = 'rgba(37,99,235,0.18)';
    for (let x = 100; x < canvas.width - 100; x += 30) {
      for (let y = 100; y < canvas.height - 100; y += 30) {
        ctx.beginPath();
        ctx.arc(x, y, 1.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Shield
    ctx.save();
    ctx.translate(canvas.width / 2, 200);
    ctx.scale(2.4, 2.4);
    ctx.fillStyle = '#2563EB';
    ctx.beginPath();
    ctx.moveTo(0, -28);
    ctx.lineTo(-24, -20);
    ctx.lineTo(-24, 4);
    ctx.bezierCurveTo(-24, 22, -10, 36, 0, 40);
    ctx.bezierCurveTo(10, 36, 24, 22, 24, 4);
    ctx.lineTo(24, -20);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#22C55E';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-10, 4);
    ctx.lineTo(-2, 14);
    ctx.lineTo(14, -8);
    ctx.stroke();
    ctx.restore();

    // Header
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.font = 'bold 56px Orbitron, sans-serif';
    ctx.fillText('CERTIFICATION OF ACHIEVEMENT', canvas.width / 2, 400);

    ctx.font = '20px JetBrains Mono, monospace';
    ctx.fillStyle = '#2563EB';
    ctx.fillText('CYBER DEFENSE ACADEMY', canvas.width / 2, 440);

    // Player name
    ctx.font = 'bold 72px Orbitron, sans-serif';
    ctx.fillStyle = '#22C55E';
    ctx.fillText(data.playerName.toUpperCase(), canvas.width / 2, 540);

    // Body text
    ctx.fillStyle = '#cbd5e1';
    ctx.font = '22px Inter, sans-serif';
    const wrap = (text: string, maxWidth: number) => {
      const words = text.split(' ');
      const lines: string[] = [];
      let line = '';
      for (const w of words) {
        const test = line ? line + ' ' + w : w;
        if (ctx.measureText(test).width > maxWidth) {
          lines.push(line);
          line = w;
        } else {
          line = test;
        }
      }
      if (line) lines.push(line);
      return lines;
    };
    wrap(certText, 1100).forEach((l, i) => {
      ctx.fillText(l, canvas.width / 2, 600 + i * 32);
    });

    // Stats row
    ctx.font = '20px JetBrains Mono, monospace';
    ctx.fillStyle = '#FACC15';
    ctx.fillText(
      `FINAL SCORE: ${data.totalScore} / 300       STARS: ${data.totalStars} / 9       DATE: ${completionDate}`,
      canvas.width / 2,
      790
    );

    // Sign-off
    ctx.font = 'italic 22px Inter, sans-serif';
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText('— Agent Maya, Cyber Defense Academy', canvas.width / 2, 870);

    // Download
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `cyber-defender-certificate-${data.playerName.replace(/\s+/g, '-')}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const copyScore = async () => {
    const text = `🛡 I just earned my CYBER DEFENDER certification at Cyber Defense Academy! Final score: ${data.totalScore}/300, Stars: ${data.totalStars}/9, completed on ${completionDate}.`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  useEffect(() => {
    // pre-warm canvas
    if (!canvasRef.current) return;
  }, []);

  return (
    <div className="min-h-screen bg-cyber-bg animate-fade-in relative overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-30" />
      {/* Confetti */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {confettiPieces.map(c => (
          <div
            key={c.id}
            className="confetti"
            style={{
              left: `${c.left}%`,
              backgroundColor: c.color,
              animationDelay: `${c.delay}s`,
              animationDuration: `${c.duration}s`,
              transform: `rotate(${c.rotate}deg)`
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-4xl mx-auto p-6 md:p-10">
        <div
          className="bg-cyber-card border-2 rounded-2xl p-10 relative"
          style={{
            borderImage: 'linear-gradient(135deg, #2563EB, #22C55E) 1',
            boxShadow: '0 0 40px rgba(37,99,235,0.4), inset 0 0 20px rgba(34,197,94,0.1)'
          }}
        >
          <div className="absolute top-3 right-3 text-xs font-mono text-slate-500">
            CERT-{Date.now().toString().slice(-8)}
          </div>

          <div className="flex justify-center mb-6">
            <svg width="100" height="100" viewBox="0 0 64 64">
              <path fill="#2563EB" d="M32 4 8 12v18c0 14 10 26 24 30 14-4 24-16 24-30V12L32 4z" />
              <path fill="#22C55E" d="m28 36-7-7-4 4 11 11 18-18-4-4z" />
            </svg>
          </div>

          <h1 className="text-center font-display text-2xl md:text-4xl tracking-widest mb-2">
            CERTIFICATION OF ACHIEVEMENT
          </h1>
          <div className="text-center font-mono text-cyber-primary text-xs tracking-[0.4em] mb-8">
            CYBER DEFENSE ACADEMY
          </div>

          <div className="text-center font-display text-5xl text-cyber-success font-black mb-8 break-words">
            {data.playerName.toUpperCase()}
          </div>

          <div className="text-center text-slate-300 text-base md:text-lg leading-relaxed max-w-3xl mx-auto">
            <TypingText text={certText} speed={18} caret={false} />
          </div>

          <div className="mt-10 grid grid-cols-3 gap-4 text-center">
            <div className="bg-cyber-bg/60 border border-cyber-border rounded-lg p-3">
              <div className="text-xs font-mono text-slate-400">FINAL SCORE</div>
              <div className="font-display text-2xl text-cyber-success font-bold">
                {data.totalScore} <span className="text-slate-500 text-base">/ 300</span>
              </div>
            </div>
            <div className="bg-cyber-bg/60 border border-cyber-border rounded-lg p-3">
              <div className="text-xs font-mono text-slate-400">TOTAL STARS</div>
              <div className="font-display text-2xl text-cyber-warning font-bold">
                ⭐ {data.totalStars} <span className="text-slate-500 text-base">/ 9</span>
              </div>
            </div>
            <div className="bg-cyber-bg/60 border border-cyber-border rounded-lg p-3">
              <div className="text-xs font-mono text-slate-400">DATE EARNED</div>
              <div className="font-display text-base text-white font-bold pt-2">{completionDate}</div>
            </div>
          </div>

          <div className="mt-10 text-center text-sm italic text-slate-400">
            — Agent Maya, Cyber Defense Academy
          </div>
        </div>

        <div className="mt-8 flex flex-col md:flex-row gap-4 justify-center">
          <Button variant="success" onClick={drawAndDownload} size="lg">
            ⬇ Download Certificate
          </Button>
          <Button variant="primary" onClick={copyScore} size="lg">
            {copied ? '✓ Copied!' : '📋 Share Score'}
          </Button>
          <Button variant="ghost" onClick={onHome} size="lg">
            ← Return to Base
          </Button>
        </div>

        <canvas ref={canvasRef} style={{ display: 'none' }} />

        <div className="mt-6 text-center text-xs font-mono text-slate-500">
          "Exceptional work, Recruit. You've demonstrated the skills of a true Cyber Defender. The Academy is proud to certify you."
        </div>
      </div>
    </div>
  );
};
