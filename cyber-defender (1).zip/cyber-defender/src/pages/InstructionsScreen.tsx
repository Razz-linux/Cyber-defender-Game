import React from 'react';
import { Button } from '../components/Button';

interface InstructionsScreenProps {
  onBack: () => void;
}

const cards = [
  {
    icon: (
      <svg viewBox="0 0 64 64" width="48" height="48">
        <path fill="#2563EB" d="M32 4 8 12v18c0 14 10 26 24 30 14-4 24-16 24-30V12L32 4z" />
      </svg>
    ),
    title: 'PHISHING DETECTION',
    sub: 'Mission 01',
    desc:
      'Analyze 10 emails from the academy inbox. Spot fake senders, suspicious links, and social engineering tricks. Classify each as SAFE or PHISHING.'
  },
  {
    icon: (
      <svg viewBox="0 0 64 64" width="48" height="48">
        <rect x="14" y="28" width="36" height="28" rx="4" fill="#2563EB" />
        <path
          d="M22 28v-8a10 10 0 0 1 20 0v8"
          stroke="#22C55E"
          strokeWidth="4"
          fill="none"
        />
      </svg>
    ),
    title: 'PASSWORD SECURITY',
    sub: 'Mission 02',
    desc:
      'Audit 10 team passwords for strength. Then design your own STRONG password with the live strength meter to lock down the network.'
  },
  {
    icon: (
      <svg viewBox="0 0 64 64" width="48" height="48">
        <circle cx="32" cy="32" r="14" fill="#EF4444" />
        <path
          d="M32 14v4M32 46v4M14 32h4M46 32h4M19 19l3 3M42 42l3 3M19 45l3-3M42 22l3-3"
          stroke="#22C55E"
          strokeWidth="3"
          strokeLinecap="round"
        />
      </svg>
    ),
    title: 'MALWARE ANALYSIS',
    sub: 'Mission 03',
    desc:
      'Explore a simulated workstation. Scan files in 4 folders, quarantine threats, and resist scam popup attacks while you defend the system.'
  }
];

export const InstructionsScreen: React.FC<InstructionsScreenProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-cyber-bg animate-fade-in relative">
      <div className="absolute inset-0 bg-grid opacity-30" />
      <div className="relative z-10 max-w-6xl mx-auto p-6 md:p-10">
        <h1 className="font-display text-3xl md:text-4xl text-white tracking-widest mb-2">
          MISSION BRIEFING
        </h1>
        <p className="text-slate-400 text-sm mb-8">
          Three missions stand between you and full Cyber Defender certification.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
          {cards.map(c => (
            <div
              key={c.title}
              className="card-lift bg-cyber-card border border-cyber-border rounded-lg p-6 flex flex-col"
            >
              <div className="flex items-center gap-3 mb-4">
                {c.icon}
                <div>
                  <div className="text-xs font-mono text-cyber-primary">{c.sub}</div>
                  <div className="font-display tracking-wider text-lg">{c.title}</div>
                </div>
              </div>
              <p className="text-slate-300 text-sm leading-relaxed flex-1">{c.desc}</p>
            </div>
          ))}
        </div>

        <div className="bg-cyber-card border border-cyber-border rounded-lg p-6">
          <h2 className="font-display tracking-widest text-cyber-primary mb-4">FIELD RULES</h2>
          <ul className="space-y-2 text-sm text-slate-300">
            <li>
              <span className="text-cyber-success font-bold">+10</span> points for each correct
              answer.
            </li>
            <li>
              <span className="text-cyber-danger font-bold">-5</span> points for each wrong answer
              (Normal). Easy mode has no penalty. Hard mode is{' '}
              <span className="text-cyber-danger font-bold">-10</span>.
            </li>
            <li>
              <span className="text-cyber-warning font-bold">-10</span> points per hint used. You
              get 3 hints per mission.
            </li>
            <li>
              ⭐ 3 stars at 90+ points, ⭐ 2 stars at 70–89, ⭐ 1 star at 50–69. Below 50 = mission
              failed.
            </li>
            <li>
              Complete all three missions to earn your{' '}
              <span className="text-cyber-primary font-bold">Cyber Defender certificate</span>.
            </li>
          </ul>
        </div>

        <div className="mt-8">
          <Button variant="ghost" onClick={onBack}>
            ← Return to Base
          </Button>
        </div>
      </div>
    </div>
  );
};
