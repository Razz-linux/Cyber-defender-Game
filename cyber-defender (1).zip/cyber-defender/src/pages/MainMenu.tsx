import React, { useEffect, useMemo, useState } from 'react';
import { Button } from '../components/Button';
import { AgentMaya } from '../components/AgentMaya';
import { TypingText } from '../components/TypingText';
import { Modal } from '../components/Modal';
import { AudioManager } from '../services/AudioManager';
import { SaveManager } from '../services/SaveManager';

interface MainMenuProps {
  onNavigate: (screen: 'levelSelect' | 'instructions' | 'settings') => void;
}

const INTRO =
  "Welcome, Recruit. I'm Agent Maya. The digital world is under constant threat. Your training begins now. Complete all three missions to earn your Cyber Defender certification.";

export const MainMenu: React.FC<MainMenuProps> = ({ onNavigate }) => {
  const [showQuit, setShowQuit] = useState(false);
  const [typingDone, setTypingDone] = useState(false);

  useEffect(() => {
    AudioManager.init();
    AudioManager.playBGM();
  }, []);

  const playerName = useMemo(() => SaveManager.loadProgress().playerName, []);

  const particles = useMemo(
    () =>
      Array.from({ length: 30 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 12,
        duration: 12 + Math.random() * 18,
        size: 2 + Math.random() * 3
      })),
    []
  );

  return (
    <div className="min-h-screen bg-cyber-bg relative overflow-hidden animate-fade-in">
      <div className="absolute inset-0 bg-grid-anim opacity-40" />
      <div className="particles">
        {particles.map(p => (
          <span
            key={p.id}
            className="particle"
            style={{
              left: `${p.left}%`,
              width: p.size,
              height: p.size,
              animationDelay: `${p.delay}s`,
              animationDuration: `${p.duration}s`
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between p-6">
        <div className="flex items-center gap-3">
          <svg width="38" height="38" viewBox="0 0 64 64">
            <path fill="#2563EB" d="M32 4 8 12v18c0 14 10 26 24 30 14-4 24-16 24-30V12L32 4z" />
            <path fill="#22C55E" d="m28 36-7-7-4 4 11 11 18-18-4-4z" />
          </svg>
          <span className="font-display tracking-widest text-lg">CYBER DEFENDER</span>
        </div>
        <div className="text-xs text-slate-500 font-mono">
          OPERATOR: <span className="text-cyber-success">{playerName.toUpperCase()}</span>
        </div>
      </header>

      {/* Center */}
      <main className="relative z-10 flex flex-col items-center justify-center px-6 py-8">
        <AgentMaya size={170} speaking={!typingDone} />

        <div className="mt-12 max-w-2xl bg-cyber-card/80 border border-cyber-border rounded-lg p-6 font-mono text-sm leading-relaxed text-slate-200">
          <div className="text-cyber-primary text-xs tracking-widest mb-2">&gt; INCOMING TRANSMISSION</div>
          <TypingText text={INTRO} onComplete={() => setTypingDone(true)} />
        </div>

        <div className="mt-10 flex flex-col gap-4 w-72">
          <Button
            variant="primary"
            full
            size="lg"
            onClick={() => onNavigate('levelSelect')}
          >
            ▶ Initialize Training
          </Button>
          <Button variant="ghost" full onClick={() => onNavigate('instructions')}>
            📋 Briefing Room
          </Button>
          <Button variant="ghost" full onClick={() => onNavigate('settings')}>
            ⚙ System Config
          </Button>
          <Button variant="danger" full onClick={() => setShowQuit(true)}>
            ⏻ Terminate Session
          </Button>
        </div>
      </main>

      <footer className="absolute bottom-3 left-0 right-0 text-center text-xs font-mono text-slate-500 z-10">
        v1.0 | Cyber Defense Academy
      </footer>

      <Modal
        open={showQuit}
        title="TERMINATE SESSION?"
        message="This will close the application. Your saved progress is safe. Continue?"
        variant="danger"
        confirmLabel="Terminate"
        onConfirm={() => {
          window.close();
          // fallback message if browser blocks window.close
          document.body.innerHTML =
            '<div style="background:#0B1020;color:#fff;font-family:Inter;padding:40px;text-align:center;height:100vh;">Session terminated. You may close this tab.</div>';
        }}
        onCancel={() => setShowQuit(false)}
      />
    </div>
  );
};
