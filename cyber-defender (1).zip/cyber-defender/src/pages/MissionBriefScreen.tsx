import React, { useState } from 'react';
import { Button } from '../components/Button';
import { AgentMaya } from '../components/AgentMaya';
import { TypingText } from '../components/TypingText';

interface MissionBriefScreenProps {
  level: number;
  onAccept: () => void;
  onCancel: () => void;
}

const BRIEFS: Record<number, { title: string; dialogue: string; objectives: string[] }> = {
  1: {
    title: 'OPERATION: INBOX CLEANUP',
    dialogue:
      'Recruit, our inbox has been flooded with suspicious emails. Analyze each one carefully. One wrong click could compromise the entire network.',
    objectives: [
      'Open and read each email in the academy inbox.',
      'Inspect the sender domain, links, urgency cues and attachments.',
      'Classify each email as SAFE or PHISHING.',
      'Reach 70+ points to earn 2 stars or higher.'
    ]
  },
  2: {
    title: 'OPERATION: LOCKDOWN',
    dialogue:
      'Good work on the phishing mission. Now we have a bigger problem — our team is using dangerously weak passwords. Audit them and fix the vulnerabilities.',
    objectives: [
      'Audit 10 team passwords as WEAK, MEDIUM, or STRONG.',
      'Watch the live strength meter as you analyze each one.',
      'Then design your own STRONG password (score ≥ 70).',
      'Bonus points for speed and high builder score.'
    ]
  },
  3: {
    title: 'OPERATION: CLEAN SWEEP',
    dialogue:
      'Final mission. A machine on our network has been infected. Boot it up, explore the file system, and quarantine every malicious file before it spreads.',
    objectives: [
      'Open each folder on the workstation desktop.',
      'Use SCAN to analyze suspicious files before deciding.',
      'QUARANTINE malware and KEEP only verified safe files.',
      'Close any scam popups by clicking the × — never the action button.'
    ]
  }
};

export const MissionBriefScreen: React.FC<MissionBriefScreenProps> = ({ level, onAccept, onCancel }) => {
  const brief = BRIEFS[level];
  const [typingDone, setTypingDone] = useState(false);

  return (
    <div className="min-h-screen bg-cyber-bg animate-fade-in relative overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-30" />
      <div className="relative z-10 max-w-5xl mx-auto p-6 md:p-10">
        <div className="flex items-center justify-between mb-8">
          <div className="font-display text-cyber-primary text-sm tracking-widest">
            ▌ INCOMING TRANSMISSION
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
            <div className="w-2 h-2 rounded-full bg-cyber-danger animate-pulse" />
            ENCRYPTED CHANNEL
          </div>
        </div>

        <h1 className="font-display text-3xl md:text-4xl tracking-widest mb-2">{brief.title}</h1>
        <div className="text-xs font-mono text-slate-500 mb-8">MISSION {String(level).padStart(2, '0')} / 03</div>

        <div className="grid grid-cols-1 md:grid-cols-[200px_1fr] gap-8 items-start">
          <div className="flex justify-center md:justify-start">
            <AgentMaya size={170} speaking={!typingDone} />
          </div>
          <div className="bg-cyber-card border border-cyber-border rounded-lg p-6 font-mono text-sm leading-relaxed">
            <div className="text-cyber-primary text-xs mb-2">AGENT MAYA:</div>
            <TypingText text={brief.dialogue} onComplete={() => setTypingDone(true)} />
          </div>
        </div>

        <div className="mt-10 bg-cyber-card border border-cyber-border rounded-lg p-6">
          <h2 className="font-display tracking-widest text-cyber-primary mb-4">▶ OBJECTIVES</h2>
          <ul className="space-y-2 text-sm text-slate-300">
            {brief.objectives.map((o, i) => (
              <li key={i} className="flex gap-2">
                <span className="text-cyber-success">▸</span>
                <span>{o}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-10 flex flex-col md:flex-row gap-4 justify-end">
          <Button variant="ghost" onClick={onCancel}>
            ← Return to Base
          </Button>
          <Button variant="success" onClick={onAccept} size="lg">
            ✓ Accept Mission
          </Button>
        </div>
      </div>
    </div>
  );
};
