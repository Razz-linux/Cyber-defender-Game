import React, { useEffect } from 'react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  useEffect(() => {
    const id = window.setTimeout(onComplete, 2500);
    return () => window.clearTimeout(id);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 bg-cyber-bg flex flex-col items-center justify-center animate-fade-in overflow-hidden">
      <div className="absolute inset-0 bg-grid-anim opacity-60" />
      <div className="absolute inset-0 bg-gradient-radial from-cyber-primary/10 via-transparent to-transparent" />

      <div className="relative z-10 flex flex-col items-center">
        <svg width="180" height="180" viewBox="0 0 200 200" className="mb-8">
          <defs>
            <linearGradient id="shieldGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#2563EB" />
              <stop offset="100%" stopColor="#22C55E" />
            </linearGradient>
          </defs>
          <path
            d="M100 12 L25 38 L25 100 C25 140 60 175 100 188 C140 175 175 140 175 100 L175 38 Z"
            fill="none"
            stroke="url(#shieldGrad)"
            strokeWidth="3"
            strokeDasharray="600"
            strokeDashoffset="600"
            style={{
              animation: 'drawStroke 1.6s ease-out forwards'
            }}
          />
          <path
            d="M70 100 L92 122 L138 76"
            fill="none"
            stroke="#22C55E"
            strokeWidth="6"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray="120"
            strokeDashoffset="120"
            style={{
              animation: 'drawStroke 1.2s 1s ease-out forwards'
            }}
          />
        </svg>

        <h1
          className="font-display text-5xl md:text-6xl font-black glitch-text"
          data-text="CYBER DEFENDER"
        >
          CYBER DEFENDER
        </h1>
        <p className="mt-4 text-slate-400 tracking-[0.4em] text-xs md:text-sm">
          CYBERSECURITY TRAINING SIMULATOR
        </p>

        <div className="mt-10 flex items-center gap-2 text-xs font-mono text-slate-500">
          <div className="w-2 h-2 bg-cyber-success rounded-full animate-pulse shadow-[0_0_8px_#22C55E]" />
          INITIALIZING SYSTEM...
        </div>
      </div>

      <style>{`
        @keyframes drawStroke { to { stroke-dashoffset: 0; } }
      `}</style>
    </div>
  );
};
