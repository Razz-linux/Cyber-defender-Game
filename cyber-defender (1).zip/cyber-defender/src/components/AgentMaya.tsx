import React from 'react';

interface AgentMayaProps {
  size?: number;
  speaking?: boolean;
}

export const AgentMaya: React.FC<AgentMayaProps> = ({ size = 180, speaking = false }) => {
  return (
    <div
      className="relative inline-block animate-fade-in"
      style={{ width: size, height: size }}
      aria-label="Agent Maya"
    >
      {/* Outer ring */}
      <div
        className="absolute inset-0 rounded-full border-2 border-cyber-primary animate-glow-pulse"
        style={{ boxShadow: '0 0 30px rgba(37,99,235,0.5)' }}
      />
      <div className="absolute inset-2 rounded-full border border-cyber-primary/40" />

      {/* Head */}
      <div
        className="absolute rounded-full bg-gradient-to-br from-cyber-secondary to-cyber-card"
        style={{ inset: '14%' }}
      >
        {/* Face */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {/* Hair */}
          <div
            className="absolute top-[8%] left-[10%] right-[10%] h-[35%] rounded-t-full"
            style={{ background: 'linear-gradient(180deg,#1E293B 0%,#0F172A 100%)' }}
          />
          {/* Visor scan line */}
          <div className="absolute top-[44%] left-[18%] right-[18%] h-[14%] bg-cyber-primary/30 rounded-md overflow-hidden">
            <div className="absolute inset-y-0 w-1/3 bg-cyber-success/80 animate-scan" />
          </div>
          {/* Eyes */}
          <div className="absolute top-[44%] left-[28%] w-[10%] h-[10%] rounded-full bg-cyber-success animate-blink shadow-[0_0_8px_#22C55E]" />
          <div className="absolute top-[44%] right-[28%] w-[10%] h-[10%] rounded-full bg-cyber-success animate-blink shadow-[0_0_8px_#22C55E]" />
          {/* Nose */}
          <div className="absolute top-[58%] left-[48%] w-[4%] h-[8%] bg-slate-500 rounded-full" />
          {/* Mouth */}
          <div
            className={`absolute left-[34%] right-[34%] bg-cyber-primary rounded-full transition-all ${
              speaking ? 'h-[8%] top-[72%] animate-pulse' : 'h-[3%] top-[74%]'
            }`}
          />
          {/* Headset arm */}
          <div className="absolute top-[24%] left-[5%] w-[6%] h-[40%] bg-cyber-border rounded-l-full" />
          <div className="absolute top-[58%] left-[3%] w-[12%] h-[10%] bg-cyber-success rounded-full shadow-[0_0_8px_#22C55E]" />
        </div>
      </div>

      {/* Label */}
      <div className="absolute -bottom-7 left-0 right-0 text-center">
        <div className="font-display text-xs tracking-[0.3em] text-cyber-primary">AGENT MAYA</div>
      </div>
    </div>
  );
};
