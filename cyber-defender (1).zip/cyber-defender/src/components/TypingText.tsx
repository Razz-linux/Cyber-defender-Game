import React, { useEffect, useState } from 'react';

interface TypingTextProps {
  text: string;
  speed?: number; // ms per char
  className?: string;
  onComplete?: () => void;
  caret?: boolean;
}

export const TypingText: React.FC<TypingTextProps> = ({
  text, speed = 28, className = '', onComplete, caret = true
}) => {
  const [displayed, setDisplayed] = useState('');
  const [done, setDone] = useState(false);

  useEffect(() => {
    setDisplayed('');
    setDone(false);
    let i = 0;
    const id = window.setInterval(() => {
      i += 1;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) {
        window.clearInterval(id);
        setDone(true);
        onComplete?.();
      }
    }, speed);
    return () => window.clearInterval(id);
  }, [text, speed, onComplete]);

  return (
    <span className={`${className} ${caret && !done ? 'caret' : ''}`}>
      {displayed}
    </span>
  );
};
