import React, { useEffect, useState } from 'react';

interface ScoreCounterProps {
  target: number;
  duration?: number;
  className?: string;
}

export const ScoreCounter: React.FC<ScoreCounterProps> = ({ target, duration = 1500, className = '' }) => {
  const [value, setValue] = useState(0);

  useEffect(() => {
    setValue(0);
    const start = performance.now();
    let frame = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setValue(Math.round(target * eased));
      if (t < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target, duration]);

  return <span className={className}>{value}</span>;
};
