import React from 'react';
import { AudioManager } from '../services/AudioManager';

type Variant = 'primary' | 'success' | 'danger' | 'ghost' | 'warning';

interface ButtonProps {
  variant?: Variant;
  onClick?: () => void;
  children: React.ReactNode;
  disabled?: boolean;
  className?: string;
  full?: boolean;
  size?: 'sm' | 'md' | 'lg';
  type?: 'button' | 'submit';
}

const variantClass: Record<Variant, string> = {
  primary: 'bg-cyber-primary hover:bg-cyber-hover text-white btn-glow',
  success: 'bg-cyber-success hover:brightness-110 text-white btn-glow-green',
  danger: 'bg-cyber-danger hover:brightness-110 text-white btn-glow-red',
  warning: 'bg-cyber-warning hover:brightness-110 text-cyber-bg',
  ghost: 'bg-transparent border border-cyber-border hover:bg-cyber-secondary text-white'
};

const sizeClass: Record<'sm' | 'md' | 'lg', string> = {
  sm: 'px-3 py-2 text-xs',
  md: 'px-5 py-3 text-sm',
  lg: 'px-8 py-4 text-base'
};

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  onClick,
  children,
  disabled,
  className = '',
  full,
  size = 'md',
  type = 'button'
}) => {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={() => {
        if (disabled) return;
        AudioManager.playSFX('click');
        onClick?.();
      }}
      className={[
        'font-display tracking-wider rounded-md transition-all duration-200 uppercase font-bold',
        sizeClass[size],
        full ? 'w-full' : '',
        disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
        variantClass[variant],
        className
      ].join(' ')}
    >
      {children}
    </button>
  );
};
