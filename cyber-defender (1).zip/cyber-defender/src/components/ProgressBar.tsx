import React from 'react';

interface ProgressBarProps {
  value: number;            // 0..100
  color?: string;
  label?: string;
  showPercent?: boolean;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ value, color = '#2563EB', label, showPercent }) => {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div className="w-full">
      {label && (
        <div className="flex justify-between text-xs text-slate-400 mb-1 font-mono">
          <span>{label}</span>
          {showPercent && <span style={{ color }}>{v}%</span>}
        </div>
      )}
      <div className="h-2 bg-cyber-card rounded-full overflow-hidden border border-cyber-border">
        <div
          className="h-full transition-all duration-500"
          style={{ width: `${v}%`, background: color }}
        />
      </div>
    </div>
  );
};
