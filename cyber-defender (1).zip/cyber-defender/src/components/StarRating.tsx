import React, { useEffect, useState } from 'react';
import { AudioManager } from '../services/AudioManager';

interface StarRatingProps {
  value: number;            // 0..3
  total?: number;
  size?: number;             // px
  animated?: boolean;
}

export const StarRating: React.FC<StarRatingProps> = ({ value, total = 3, size = 32, animated = false }) => {
  const [filled, setFilled] = useState(animated ? 0 : value);

  useEffect(() => {
    if (!animated) {
      setFilled(value);
      return;
    }
    setFilled(0);
    let cur = 0;
    const id = window.setInterval(() => {
      cur += 1;
      if (cur > value) {
        window.clearInterval(id);
        return;
      }
      AudioManager.playSFX('star');
      setFilled(cur);
    }, 450);
    return () => window.clearInterval(id);
  }, [value, animated]);

  return (
    <div className="flex items-center gap-2">
      {Array.from({ length: total }).map((_, i) => {
        const on = i < filled;
        const popClass = animated && i === filled - 1 ? 'animate-star-pop' : '';
        return (
          <svg
            key={i}
            width={size}
            height={size}
            viewBox="0 0 24 24"
            className={popClass}
            style={{
              filter: on ? 'drop-shadow(0 0 8px #FACC15)' : 'none',
              transition: 'all 0.3s'
            }}
          >
            <path
              d="M12 2l2.9 6.2 6.8.8-5 4.7 1.4 6.8L12 17.5 5.9 20.5l1.4-6.8-5-4.7 6.8-.8L12 2z"
              fill={on ? '#FACC15' : 'transparent'}
              stroke={on ? '#FACC15' : '#475569'}
              strokeWidth="1.5"
              strokeLinejoin="round"
            />
          </svg>
        );
      })}
    </div>
  );
};
