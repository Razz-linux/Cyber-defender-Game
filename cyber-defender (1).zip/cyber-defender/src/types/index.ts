// All TypeScript interfaces for Cyber Defender

export type Screen =
  | 'splash'
  | 'menu'
  | 'instructions'
  | 'settings'
  | 'levelSelect'
  | 'brief'
  | 'game'
  | 'result'
  | 'certificate';

export type Difficulty = 'easy' | 'normal' | 'hard';

export interface Settings {
  music: boolean;
  sound: boolean;
  difficulty: Difficulty;
}

export interface SaveData {
  completedLevels: number[];
  levelStars: Record<string, number>;
  levelScores: Record<string, number>;
  bestScores: Record<string, number>;
  totalScore: number;
  totalStars: number;
  settings: Settings;
  playerName: string;
  completionTime: string | null;
  certificateEarned: boolean;
}

export interface PhishingEmail {
  id: number;
  from: string;
  fromAddress: string;
  to: string;
  subject: string;
  date: string;
  body: string;
  attachments: string[];
  isPhishing: boolean;
  redFlags: string[];
  explanation: string;
}

export type PasswordStrength = 'weak' | 'medium' | 'strong';

export interface PasswordEntry {
  id: number;
  password: string;
  strength: PasswordStrength;
  score: number;
  feedback: string;
  crackTime: string;
}

export type FileStatus = 'safe' | 'malware' | 'suspicious';

export interface FileEntry {
  id: number;
  name: string;
  type: string;
  size: string;
  folder: 'Downloads' | 'Desktop Files' | 'Documents' | 'Pictures';
  isMalware: boolean;
  status: FileStatus;
  malwareType: string | null;
  scanResult: string;
  recommendedAction: 'KEEP' | 'QUARANTINE';
  explanation: string;
}

export interface LevelResult {
  level: number;
  score: number;
  stars: number;
  correct: number;
  wrong: number;
  hintsUsed: number;
  timeTaken: number;
  learningPoints: string[];
}

export interface GameState {
  currentLevel: number;
  currentScore: number;
  hintsRemaining: number;
  startTime: number;
  correct: number;
  wrong: number;
  hintsUsed: number;
}
