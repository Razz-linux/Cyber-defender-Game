import { useEffect, useState } from 'react';
import { EventBus } from '../game/EventBus';

interface LiveGameState {
  score: number;
  hintsRemaining: number;
}

export function useGameState(): LiveGameState {
  const [state, setState] = useState<LiveGameState>({ score: 0, hintsRemaining: 3 });

  useEffect(() => {
    const onUpdate = (payload: { score: number; hintsRemaining: number }) => setState(payload);
    EventBus.on('scoreUpdate', onUpdate);
    return () => {
      EventBus.off('scoreUpdate', onUpdate);
    };
  }, []);

  return state;
}
