import { useCallback, useEffect, useState } from 'react';
import { SaveManager } from '../services/SaveManager';
import type { SaveData } from '../types';

export function useSaveManager() {
  const [data, setData] = useState<SaveData>(() => SaveManager.loadProgress());

  const refresh = useCallback(() => {
    setData(SaveManager.loadProgress());
  }, []);

  useEffect(() => {
    const handler = () => refresh();
    window.addEventListener('storage', handler);
    return () => window.removeEventListener('storage', handler);
  }, [refresh]);

  return { data, refresh };
}
