import type { PasswordEntry } from '../types';

const weakFeedback = 'This password would be cracked in under 1 second by automated tools.';
const mediumFeedback = 'Better, but still vulnerable. Add special characters and increase length.';
const strongFeedback = 'Excellent! This password would take centuries to crack by brute force.';

export const passwords: PasswordEntry[] = [
  // ---------------- WEAK ----------------
  { id: 1, password: '123456', strength: 'weak', score: 5, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 2, password: 'password', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 3, password: 'admin', strength: 'weak', score: 5, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 4, password: 'qwerty', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 5, password: '123456789', strength: 'weak', score: 12, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 6, password: 'iloveyou', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 7, password: 'welcome', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 8, password: 'monkey', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 9, password: 'dragon', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 10, password: 'master', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 11, password: 'abc123', strength: 'weak', score: 15, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 12, password: 'letmein', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 13, password: 'sunshine', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 14, password: 'princess', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 15, password: 'shadow', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 16, password: 'superman', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 17, password: '111111', strength: 'weak', score: 5, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 18, password: 'baseball', strength: 'weak', score: 10, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 19, password: 'pass', strength: 'weak', score: 5, feedback: weakFeedback, crackTime: 'Instant' },
  { id: 20, password: '000000', strength: 'weak', score: 5, feedback: weakFeedback, crackTime: 'Instant' },

  // ---------------- MEDIUM ----------------
  { id: 21, password: 'Welcome1', strength: 'medium', score: 45, feedback: mediumFeedback, crackTime: '6 minutes' },
  { id: 22, password: 'Summer2024', strength: 'medium', score: 50, feedback: mediumFeedback, crackTime: '12 minutes' },
  { id: 23, password: 'John1990!', strength: 'medium', score: 55, feedback: mediumFeedback, crackTime: '1 hour' },
  { id: 24, password: 'Mumbai@1', strength: 'medium', score: 50, feedback: mediumFeedback, crackTime: '30 minutes' },
  { id: 25, password: 'Qwerty123', strength: 'medium', score: 45, feedback: mediumFeedback, crackTime: '15 minutes' },
  { id: 26, password: 'Admin@2024', strength: 'medium', score: 55, feedback: mediumFeedback, crackTime: '2 hours' },
  { id: 27, password: 'Batman99!', strength: 'medium', score: 60, feedback: mediumFeedback, crackTime: '3 hours' },
  { id: 28, password: 'India@123', strength: 'medium', score: 55, feedback: mediumFeedback, crackTime: '1 hour' },
  { id: 29, password: 'Password1!', strength: 'medium', score: 60, feedback: mediumFeedback, crackTime: '4 hours' },
  { id: 30, password: 'Hockey2023', strength: 'medium', score: 50, feedback: mediumFeedback, crackTime: '20 minutes' },
  { id: 31, password: 'Secure01!', strength: 'medium', score: 60, feedback: mediumFeedback, crackTime: '3 hours' },
  { id: 32, password: 'Hello@World', strength: 'medium', score: 65, feedback: mediumFeedback, crackTime: '8 hours' },
  { id: 33, password: 'Tiger2024!', strength: 'medium', score: 65, feedback: mediumFeedback, crackTime: '10 hours' },
  { id: 34, password: 'Nepal#456', strength: 'medium', score: 55, feedback: mediumFeedback, crackTime: '2 hours' },
  { id: 35, password: 'Winter$99', strength: 'medium', score: 55, feedback: mediumFeedback, crackTime: '2 hours' },

  // ---------------- STRONG ----------------
  { id: 36, password: 'Safe@Tiger2026!', strength: 'strong', score: 85, feedback: strongFeedback, crackTime: '34 years' },
  { id: 37, password: 'Cyber$Defender#99', strength: 'strong', score: 92, feedback: strongFeedback, crackTime: '2 centuries' },
  { id: 38, password: 'R3dF0x!Secure@2024', strength: 'strong', score: 95, feedback: strongFeedback, crackTime: '4 centuries' },
  { id: 39, password: 'Mango!Tree$River#42', strength: 'strong', score: 96, feedback: strongFeedback, crackTime: '5 centuries' },
  { id: 40, password: 'Xk#9mP2$vQn!8rLw', strength: 'strong', score: 100, feedback: strongFeedback, crackTime: '10+ centuries' },
  { id: 41, password: 'BlueSky@Mountain#2024', strength: 'strong', score: 94, feedback: strongFeedback, crackTime: '3 centuries' },
  { id: 42, password: 'J@smine$Flower2026!', strength: 'strong', score: 94, feedback: strongFeedback, crackTime: '3 centuries' },
  { id: 43, password: 'P!nkFl@mingo99$secure', strength: 'strong', score: 96, feedback: strongFeedback, crackTime: '6 centuries' },
  { id: 44, password: 'Qu!ck#Brown$F0x2024', strength: 'strong', score: 93, feedback: strongFeedback, crackTime: '2 centuries' },
  { id: 45, password: 'Vel0city@Storm#2026', strength: 'strong', score: 92, feedback: strongFeedback, crackTime: '2 centuries' },
  { id: 46, password: 'Th3$ecure#P@ssw0rd!', strength: 'strong', score: 94, feedback: strongFeedback, crackTime: '3 centuries' },
  { id: 47, password: 'Galaxy#Star!N3bula$', strength: 'strong', score: 92, feedback: strongFeedback, crackTime: '2 centuries' },
  { id: 48, password: 'F1reW@ll$Secur1ty#26', strength: 'strong', score: 95, feedback: strongFeedback, crackTime: '4 centuries' },
  { id: 49, password: '@rcticWolf#42$Sp33d', strength: 'strong', score: 93, feedback: strongFeedback, crackTime: '2 centuries' },
  { id: 50, password: 'N3ptune@D3ep$Ocean!24', strength: 'strong', score: 96, feedback: strongFeedback, crackTime: '5 centuries' }
];

const COMMON_PASSWORDS = new Set([
  '123456', 'password', 'admin', 'qwerty', '123456789', 'iloveyou', 'welcome',
  'monkey', 'dragon', 'master', 'abc123', 'letmein', 'sunshine', 'princess',
  'shadow', 'superman', '111111', 'baseball', 'pass', '000000', '12345',
  '1234', '12345678', 'password1', 'qwerty123', 'admin123'
]);

export function calculatePasswordScore(pwd: string): number {
  if (!pwd) return 0;
  let score = 0;

  // length
  if (pwd.length >= 16) score += 35;
  else if (pwd.length >= 12) score += 25;
  else if (pwd.length >= 8) score += 10;
  else if (pwd.length >= 6) score += 5;

  // character classes
  if (/[A-Z]/.test(pwd)) score += 20;
  if (/[a-z]/.test(pwd)) score += 10;
  if (/[0-9]/.test(pwd)) score += 15;
  if (/[^A-Za-z0-9]/.test(pwd)) score += 20;

  // common password penalty
  if (COMMON_PASSWORDS.has(pwd.toLowerCase())) score -= 50;

  // repeated characters
  if (/(.)\1{2,}/.test(pwd)) score -= 10;

  // sequential patterns (lowercase + numbers)
  const lower = pwd.toLowerCase();
  const sequences = [
    'abcdefghijklmnopqrstuvwxyz',
    '0123456789',
    'qwertyuiop',
    'asdfghjkl',
    'zxcvbnm'
  ];
  for (const seq of sequences) {
    for (let i = 0; i <= seq.length - 4; i++) {
      const fragment = seq.substring(i, i + 4);
      if (lower.includes(fragment)) {
        score -= 10;
        break;
      }
    }
  }

  return Math.max(0, Math.min(100, score));
}

export function strengthFromScore(score: number): 'weak' | 'medium' | 'strong' {
  if (score < 40) return 'weak';
  if (score < 70) return 'medium';
  return 'strong';
}
