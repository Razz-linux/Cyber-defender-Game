import { SaveManager } from './SaveManager';

/**
 * AudioManager — generates simple beeps & ambient music using the Web Audio API.
 * No external audio files required (everything is browser-native).
 */
class AudioManagerClass {
  private ctx: AudioContext | null = null;
  private musicGain: GainNode | null = null;
  private musicNodes: OscillatorNode[] = [];
  private musicPlaying = false;
  private musicOn = true;
  private soundOn = true;

  init(): void {
    const settings = SaveManager.loadProgress().settings;
    this.musicOn = settings.music;
    this.soundOn = settings.sound;
  }

  private ensureCtx(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      try {
        const AC: typeof AudioContext =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.ctx = new AC();
      } catch {
        return null;
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => undefined);
    }
    return this.ctx;
  }

  setMusic(on: boolean): void {
    this.musicOn = on;
    if (on) this.playBGM();
    else this.stopBGM();
  }

  setSound(on: boolean): void {
    this.soundOn = on;
  }

  toggleMusic(): void {
    this.setMusic(!this.musicOn);
  }

  toggleSound(): void {
    this.setSound(!this.soundOn);
  }

  playBGM(): void {
    if (!this.musicOn || this.musicPlaying) return;
    const ctx = this.ensureCtx();
    if (!ctx) return;

    this.musicGain = ctx.createGain();
    this.musicGain.gain.value = 0.04;
    this.musicGain.connect(ctx.destination);

    // ambient cyber drone: two detuned oscillators
    const baseFreqs = [110, 165, 220];
    baseFreqs.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = i === 0 ? 'sine' : 'triangle';
      osc.frequency.value = freq;
      osc.detune.value = i * 5;
      const filt = ctx.createBiquadFilter();
      filt.type = 'lowpass';
      filt.frequency.value = 800;
      osc.connect(filt);
      filt.connect(this.musicGain!);
      osc.start();
      this.musicNodes.push(osc);
    });

    // subtle LFO on the gain
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.18;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.02;
    lfo.connect(lfoGain);
    lfoGain.connect(this.musicGain!.gain);
    lfo.start();
    this.musicNodes.push(lfo);

    this.musicPlaying = true;
  }

  stopBGM(): void {
    this.musicNodes.forEach(n => {
      try { n.stop(); } catch { /* noop */ }
      try { n.disconnect(); } catch { /* noop */ }
    });
    this.musicNodes = [];
    if (this.musicGain) {
      try { this.musicGain.disconnect(); } catch { /* noop */ }
      this.musicGain = null;
    }
    this.musicPlaying = false;
  }

  playSFX(name: string): void {
    if (!this.soundOn) return;
    const ctx = this.ensureCtx();
    if (!ctx) return;

    switch (name) {
      case 'correct':
        this.beep(ctx, 880, 0.08, 'sine', 0.2);
        setTimeout(() => this.beep(ctx, 1320, 0.12, 'sine', 0.18), 80);
        break;
      case 'wrong':
        this.beep(ctx, 220, 0.18, 'square', 0.18);
        setTimeout(() => this.beep(ctx, 165, 0.18, 'square', 0.18), 100);
        break;
      case 'click':
        this.beep(ctx, 660, 0.04, 'square', 0.08);
        break;
      case 'hint':
        this.beep(ctx, 520, 0.1, 'triangle', 0.18);
        setTimeout(() => this.beep(ctx, 660, 0.1, 'triangle', 0.18), 90);
        break;
      case 'star':
        this.beep(ctx, 990, 0.08, 'sine', 0.2);
        setTimeout(() => this.beep(ctx, 1320, 0.1, 'sine', 0.18), 70);
        setTimeout(() => this.beep(ctx, 1760, 0.14, 'sine', 0.18), 140);
        break;
      case 'win':
        [523, 659, 784, 1047].forEach((f, i) => {
          setTimeout(() => this.beep(ctx, f, 0.16, 'sine', 0.22), i * 120);
        });
        break;
      case 'lose':
        [400, 320, 240, 180].forEach((f, i) => {
          setTimeout(() => this.beep(ctx, f, 0.2, 'sawtooth', 0.18), i * 130);
        });
        break;
      case 'popup':
        this.beep(ctx, 880, 0.06, 'square', 0.1);
        setTimeout(() => this.beep(ctx, 440, 0.1, 'square', 0.1), 70);
        break;
      default:
        this.beep(ctx, 660, 0.04, 'square', 0.08);
    }
  }

  private beep(ctx: AudioContext, freq: number, dur: number, type: OscillatorType, vol: number): void {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.value = 0;
    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(vol, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);

    osc.start(now);
    osc.stop(now + dur + 0.02);
  }
}

export const AudioManager = new AudioManagerClass();
