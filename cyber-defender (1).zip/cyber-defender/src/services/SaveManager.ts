import type { SaveData, Settings } from '../types';

const SAVE_KEY = 'cyberDefenderSave';

const defaultData: SaveData = {
  completedLevels: [],
  levelStars: { '1': 0, '2': 0, '3': 0 },
  levelScores: { '1': 0, '2': 0, '3': 0 },
  bestScores: { '1': 0, '2': 0, '3': 0 },
  totalScore: 0,
  totalStars: 0,
  settings: {
    music: true,
    sound: true,
    difficulty: 'normal'
  },
  playerName: 'Recruit',
  completionTime: null,
  certificateEarned: false
};

class SaveManagerClass {
  private cache: SaveData | null = null;

  private clone(d: SaveData): SaveData {
    return JSON.parse(JSON.stringify(d));
  }

  loadProgress(): SaveData {
    if (this.cache) return this.clone(this.cache);
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) {
        this.cache = this.clone(defaultData);
        return this.clone(this.cache);
      }
      const parsed = JSON.parse(raw) as Partial<SaveData>;
      // merge with defaults to be safe
      const merged: SaveData = {
        ...defaultData,
        ...parsed,
        levelStars: { ...defaultData.levelStars, ...(parsed.levelStars || {}) },
        levelScores: { ...defaultData.levelScores, ...(parsed.levelScores || {}) },
        bestScores: { ...defaultData.bestScores, ...(parsed.bestScores || {}) },
        settings: { ...defaultData.settings, ...(parsed.settings || {}) }
      };
      this.cache = merged;
      return this.clone(merged);
    } catch (err) {
      console.error('SaveManager.loadProgress error', err);
      this.cache = this.clone(defaultData);
      return this.clone(this.cache);
    }
  }

  saveProgress(data: SaveData): void {
    try {
      this.cache = this.clone(data);
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch (err) {
      console.error('SaveManager.saveProgress error', err);
    }
  }

  resetGame(): void {
    try {
      localStorage.removeItem(SAVE_KEY);
      this.cache = this.clone(defaultData);
    } catch (err) {
      console.error('SaveManager.resetGame error', err);
    }
  }

  unlockLevel(levelNumber: number): void {
    const data = this.loadProgress();
    if (!data.completedLevels.includes(levelNumber)) {
      data.completedLevels.push(levelNumber);
      data.completedLevels.sort((a, b) => a - b);
      this.saveProgress(data);
    }
  }

  saveScore(levelNumber: number, score: number, stars: number): void {
    const data = this.loadProgress();
    const key = String(levelNumber);
    data.levelScores[key] = score;
    data.levelStars[key] = Math.max(data.levelStars[key] || 0, stars);
    data.bestScores[key] = Math.max(data.bestScores[key] || 0, score);

    if (stars > 0 && !data.completedLevels.includes(levelNumber)) {
      data.completedLevels.push(levelNumber);
      data.completedLevels.sort((a, b) => a - b);
    }

    // recompute totals
    data.totalScore = (data.bestScores['1'] || 0) + (data.bestScores['2'] || 0) + (data.bestScores['3'] || 0);
    data.totalStars = (data.levelStars['1'] || 0) + (data.levelStars['2'] || 0) + (data.levelStars['3'] || 0);

    if (data.completedLevels.includes(1) && data.completedLevels.includes(2) && data.completedLevels.includes(3)) {
      if (!data.certificateEarned) {
        data.certificateEarned = true;
        data.completionTime = new Date().toISOString();
      }
    }

    this.saveProgress(data);
  }

  saveSettings(settings: Settings): void {
    const data = this.loadProgress();
    data.settings = { ...data.settings, ...settings };
    this.saveProgress(data);
  }

  savePlayerName(name: string): void {
    const data = this.loadProgress();
    data.playerName = name && name.trim().length > 0 ? name.trim() : 'Recruit';
    this.saveProgress(data);
  }

  getCompletedLevels(): number[] {
    return this.loadProgress().completedLevels;
  }

  isLevelUnlocked(levelNumber: number): boolean {
    if (levelNumber === 1) return true;
    const completed = this.getCompletedLevels();
    return completed.includes(levelNumber - 1);
  }
}

export const SaveManager = new SaveManagerClass();
