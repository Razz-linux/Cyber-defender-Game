import type { GameState, LevelResult } from '../types';

class GameManagerClass {
  state: GameState = {
    currentLevel: 1,
    currentScore: 0,
    hintsRemaining: 3,
    startTime: Date.now(),
    correct: 0,
    wrong: 0,
    hintsUsed: 0
  };

  lastResult: LevelResult | null = null;

  reset(level: number): void {
    this.state = {
      currentLevel: level,
      currentScore: 0,
      hintsRemaining: 3,
      startTime: Date.now(),
      correct: 0,
      wrong: 0,
      hintsUsed: 0
    };
  }

  addScore(delta: number): void {
    this.state.currentScore = Math.max(0, Math.min(100, this.state.currentScore + delta));
  }

  useHint(): boolean {
    if (this.state.hintsRemaining <= 0) return false;
    this.state.hintsRemaining -= 1;
    this.state.hintsUsed += 1;
    this.addScore(-10);
    return true;
  }

  markCorrect(points = 10): void {
    this.state.correct += 1;
    this.addScore(points);
  }

  markWrong(penalty = 5): void {
    this.state.wrong += 1;
    this.addScore(-penalty);
  }

  computeStars(score: number): number {
    if (score >= 90) return 3;
    if (score >= 70) return 2;
    if (score >= 50) return 1;
    return 0;
  }

  finalize(learningPoints: string[]): LevelResult {
    const score = this.state.currentScore;
    const stars = this.computeStars(score);
    const result: LevelResult = {
      level: this.state.currentLevel,
      score,
      stars,
      correct: this.state.correct,
      wrong: this.state.wrong,
      hintsUsed: this.state.hintsUsed,
      timeTaken: Math.floor((Date.now() - this.state.startTime) / 1000),
      learningPoints
    };
    this.lastResult = result;
    return result;
  }
}

export const GameManager = new GameManagerClass();
