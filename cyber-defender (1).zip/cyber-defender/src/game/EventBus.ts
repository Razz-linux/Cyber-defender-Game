import EventEmitter from 'eventemitter3';

/**
 * Global event bus shared between React UI and Phaser scenes.
 *
 * Events:
 *   'levelComplete' { level, score, stars, correct, wrong, hintsUsed, timeTaken, learningPoints }
 *   'scoreUpdate'   { score, hintsRemaining }
 *   'gameOver'      { level }
 *   'hintRequest'   (React → Phaser)
 *   'sceneReady'    { level }
 */
export const EventBus = new EventEmitter();
