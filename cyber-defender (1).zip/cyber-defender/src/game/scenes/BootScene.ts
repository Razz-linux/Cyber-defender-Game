import Phaser from 'phaser';

export class BootScene extends Phaser.Scene {
  constructor() {
    super('BootScene');
  }

  preload(): void {
    const { width, height } = this.scale;

    // Loading bar UI
    const barBg = this.add.rectangle(width / 2, height / 2, 400, 8, 0x1e293b).setOrigin(0.5);
    const bar = this.add.rectangle(width / 2 - 200, height / 2, 0, 8, 0x2563eb).setOrigin(0, 0.5);
    const label = this.add.text(width / 2, height / 2 - 40, 'INITIALIZING SYSTEM...', {
      fontFamily: 'Orbitron, sans-serif',
      fontSize: '20px',
      color: '#2563EB'
    }).setOrigin(0.5);
    const pct = this.add.text(width / 2, height / 2 + 30, '0%', {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '14px',
      color: '#94a3b8'
    }).setOrigin(0.5);

    // Generate small textures programmatically (no external assets required)
    this.load.on('progress', (p: number) => {
      bar.width = 400 * p;
      pct.setText(`${Math.floor(p * 100)}%`);
    });

    // Force one tiny "load" so progress fires
    const g = this.make.graphics({ x: 0, y: 0 }, false);
    g.fillStyle(0xffffff, 1);
    g.fillRect(0, 0, 2, 2);
    g.generateTexture('px', 2, 2);
    g.destroy();

    this.load.on('complete', () => {
      label.destroy();
      pct.destroy();
      barBg.destroy();
      bar.destroy();
      const level = this.registry.get('level') as number;
      if (level === 1) this.scene.start('PhishingScene');
      else if (level === 2) this.scene.start('PasswordScene');
      else this.scene.start('MalwareScene');
    });
  }

  create(): void {
    // Faking a tiny load so the complete handler fires reliably
    this.time.delayedCall(400, () => {
      const level = this.registry.get('level') as number;
      if (level === 1) this.scene.start('PhishingScene');
      else if (level === 2) this.scene.start('PasswordScene');
      else this.scene.start('MalwareScene');
    });
  }
}
