import Phaser from 'phaser';
import { EventBus } from '../EventBus';
import { GameManager } from '../../services/GameManager';
import { AudioManager } from '../../services/AudioManager';
import { SaveManager } from '../../services/SaveManager';
import { phishingEmails } from '../../data/phishingQuestions';
import type { PhishingEmail } from '../../types';

interface EmailState {
  email: PhishingEmail;
  answered: boolean;
  correct: boolean | null;
}

export class PhishingScene extends Phaser.Scene {
  private emails: EmailState[] = [];
  private selectedIndex = 0;
  private dom!: Phaser.GameObjects.DOMElement;
  private timerEvent!: Phaser.Time.TimerEvent;
  private timeLeft = 180;
  private difficulty: 'easy' | 'normal' | 'hard' = 'normal';
  private flashOverlay!: Phaser.GameObjects.Rectangle;

  constructor() {
    super('PhishingScene');
  }

  create(): void {
    GameManager.reset(1);
    const settings = SaveManager.loadProgress().settings;
    this.difficulty = settings.difficulty;
    if (this.difficulty === 'hard') this.timeLeft = 150;
    else if (this.difficulty === 'easy') this.timeLeft = 240;
    else this.timeLeft = 180;

    // Randomly pick 10 of 20 emails
    const shuffled = [...phishingEmails].sort(() => Math.random() - 0.5).slice(0, 10);
    this.emails = shuffled.map(email => ({ email, answered: false, correct: null }));

    // Background
    this.cameras.main.setBackgroundColor('#0B1020');

    // DOM container that fills the scene
    const { width, height } = this.scale;
    this.dom = this.add.dom(width / 2, height / 2).createFromHTML(this.buildHTML());
    this.dom.setOrigin(0.5);

    // Flash overlay for feedback (correct/wrong)
    this.flashOverlay = this.add
      .rectangle(width / 2, height / 2, width, height, 0x000000, 0)
      .setDepth(1000);

    this.bindDomHandlers();
    this.renderInbox();
    this.renderEmail();
    this.updateHeader();

    // Timer
    this.timerEvent = this.time.addEvent({
      delay: 1000,
      callback: () => {
        this.timeLeft -= 1;
        this.updateHeader();
        if (this.timeLeft <= 0) this.finishLevel();
      },
      loop: true
    });

    EventBus.emit('sceneReady', { level: 1 });

    EventBus.on('hintRequest', this.handleHintRequest, this);
    this.events.on(Phaser.Scenes.Events.SHUTDOWN, () => {
      EventBus.off('hintRequest', this.handleHintRequest, this);
    });
  }

  private buildHTML(): string {
    const { width, height } = this.scale;
    return `
<div id="phish-root" style="
  width:${width - 40}px;
  height:${height - 40}px;
  background:#0F172A;
  border:1px solid #334155;
  border-radius:10px;
  display:grid;
  grid-template-rows:54px 1fr;
  font-family:Inter, sans-serif;
  color:#fff;
  overflow:hidden;
">
  <!-- Top bar -->
  <div style="background:#1E293B;border-bottom:1px solid #334155;padding:0 16px;display:flex;align-items:center;justify-content:space-between;gap:12px;">
    <div style="display:flex;align-items:center;gap:10px;">
      <div style="width:10px;height:10px;background:#22C55E;border-radius:50%;box-shadow:0 0 8px #22C55E;"></div>
      <div style="font-family:'Orbitron',sans-serif;font-size:14px;color:#94A3B8;letter-spacing:1px;">
        PHISHING ANALYSIS TERMINAL — MISSION 1 / 3
      </div>
    </div>
    <div style="display:flex;align-items:center;gap:20px;font-family:'JetBrains Mono',monospace;font-size:13px;">
      <div>⏱ <span id="phish-timer" style="color:#FACC15;">3:00</span></div>
      <div>SCORE: <span id="phish-score" style="color:#22C55E;">0</span></div>
      <div>HINTS: <span id="phish-hints" style="color:#2563EB;">3</span></div>
      <div>PROGRESS: <span id="phish-progress">0/10</span></div>
    </div>
  </div>

  <!-- Main 3-column layout -->
  <div style="display:grid;grid-template-columns:160px 320px 1fr;height:100%;min-height:0;">
    <!-- Sidebar -->
    <div style="background:#0B1020;border-right:1px solid #334155;padding:14px 10px;font-size:13px;">
      <div style="font-family:'Orbitron',sans-serif;color:#2563EB;font-size:12px;margin-bottom:10px;letter-spacing:1px;">FOLDERS</div>
      <div style="padding:8px;background:#1E293B;border-radius:6px;margin-bottom:4px;display:flex;justify-content:space-between;">
        <span>📥 Inbox</span><span id="phish-inbox-count" style="color:#94A3B8;">10</span>
      </div>
      <div style="padding:8px;color:#94A3B8;">📤 Sent</div>
      <div style="padding:8px;color:#94A3B8;">📝 Drafts</div>
      <div style="padding:8px;color:#94A3B8;">🚫 Spam</div>

      <div style="margin-top:24px;font-family:'Orbitron',sans-serif;color:#2563EB;font-size:12px;margin-bottom:8px;letter-spacing:1px;">TOOLS</div>
      <button id="phish-hint-btn" style="
        width:100%;padding:10px;background:#2563EB;color:#fff;border:none;border-radius:6px;
        cursor:pointer;font-family:'Orbitron',sans-serif;font-size:12px;letter-spacing:1px;">
        💡 USE HINT (-10)
      </button>
    </div>

    <!-- Email list -->
    <div id="phish-list" style="background:#0F172A;border-right:1px solid #334155;overflow-y:auto;">
    </div>

    <!-- Reader -->
    <div id="phish-reader" style="background:#0B1020;padding:18px;overflow-y:auto;font-size:14px;">
    </div>
  </div>
</div>
    `;
  }

  private bindDomHandlers(): void {
    const root = this.dom.node as HTMLElement;
    root.querySelector('#phish-hint-btn')?.addEventListener('click', () => this.handleHintRequest());
  }

  private renderInbox(): void {
    const root = this.dom.node as HTMLElement;
    const list = root.querySelector('#phish-list') as HTMLElement;
    list.innerHTML = '';
    this.emails.forEach((s, i) => {
      const item = document.createElement('div');
      const selected = i === this.selectedIndex;
      const icon = s.answered ? (s.correct ? '✅' : '❌') : '✉️';
      item.style.cssText = `
        padding:10px 12px;border-bottom:1px solid #1E293B;cursor:pointer;
        background:${selected ? '#1E293B' : 'transparent'};
        border-left:3px solid ${selected ? '#2563EB' : 'transparent'};
      `;
      item.innerHTML = `
        <div style="display:flex;justify-content:space-between;font-size:12px;color:#94A3B8;">
          <span>${icon} ${this.escape(s.email.from)}</span>
          <span>${s.email.date.split(' ')[1] || ''}</span>
        </div>
        <div style="font-weight:600;font-size:13px;margin-top:3px;color:${selected ? '#fff' : '#cbd5e1'};">
          ${this.escape(s.email.subject)}
        </div>
      `;
      item.addEventListener('click', () => {
        this.selectedIndex = i;
        this.renderInbox();
        this.renderEmail();
      });
      list.appendChild(item);
    });
    (root.querySelector('#phish-inbox-count') as HTMLElement).textContent = String(this.emails.filter(e => !e.answered).length);
  }

  private renderEmail(): void {
    const root = this.dom.node as HTMLElement;
    const reader = root.querySelector('#phish-reader') as HTMLElement;
    const s = this.emails[this.selectedIndex];
    if (!s) return;
    const e = s.email;

    const buttonsDisabled = s.answered;
    const attachmentsHTML = e.attachments.length
      ? `<div style="margin-top:10px;padding:8px;background:#1E293B;border-radius:6px;font-size:12px;color:#FACC15;">
          📎 Attachments: ${e.attachments.map(a => this.escape(a)).join(', ')}
         </div>`
      : '';

    const explanationHTML = s.answered
      ? `<div style="margin-top:14px;padding:12px;border-radius:6px;background:${s.correct ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)'};
            border:1px solid ${s.correct ? '#22C55E' : '#EF4444'};font-size:13px;">
          <strong style="color:${s.correct ? '#22C55E' : '#EF4444'};">
            ${s.correct ? '✓ CORRECT ANALYSIS' : '✗ INCORRECT ANALYSIS'} — ${e.isPhishing ? 'PHISHING' : 'SAFE'}
          </strong>
          <div style="margin-top:6px;color:#cbd5e1;">${this.escape(e.explanation)}</div>
          ${e.redFlags.length ? `<div style="margin-top:8px;color:#FACC15;font-size:12px;">Red flags: ${e.redFlags.map(r => this.escape(r)).join(' • ')}</div>` : ''}
        </div>`
      : '';

    reader.innerHTML = `
      <div style="border-bottom:1px solid #334155;padding-bottom:12px;margin-bottom:14px;">
        <div style="font-family:'Orbitron',sans-serif;font-size:18px;color:#fff;margin-bottom:8px;">
          ${this.escape(e.subject)}
        </div>
        <div style="font-size:12px;color:#94A3B8;line-height:1.7;">
          <div><strong style="color:#cbd5e1;">From:</strong> ${this.escape(e.from)} &lt;<span style="color:#FACC15;">${this.escape(e.fromAddress)}</span>&gt;</div>
          <div><strong style="color:#cbd5e1;">To:</strong> ${this.escape(e.to)}</div>
          <div><strong style="color:#cbd5e1;">Date:</strong> ${this.escape(e.date)}</div>
        </div>
      </div>
      <div style="line-height:1.7;color:#e2e8f0;font-size:14px;">
        ${e.body}
      </div>
      ${attachmentsHTML}

      <div style="margin-top:24px;display:flex;gap:12px;">
        <button id="phish-safe-btn" ${buttonsDisabled ? 'disabled' : ''} style="
          flex:1;padding:14px;background:${buttonsDisabled ? '#475569' : '#22C55E'};
          color:#fff;border:none;border-radius:6px;cursor:${buttonsDisabled ? 'not-allowed' : 'pointer'};
          font-family:'Orbitron',sans-serif;font-size:14px;letter-spacing:1px;font-weight:700;">
          ✓ MARK AS SAFE
        </button>
        <button id="phish-phish-btn" ${buttonsDisabled ? 'disabled' : ''} style="
          flex:1;padding:14px;background:${buttonsDisabled ? '#475569' : '#EF4444'};
          color:#fff;border:none;border-radius:6px;cursor:${buttonsDisabled ? 'not-allowed' : 'pointer'};
          font-family:'Orbitron',sans-serif;font-size:14px;letter-spacing:1px;font-weight:700;">
          ⚠ MARK AS PHISHING
        </button>
      </div>
      ${explanationHTML}

      ${s.answered ? `
        <button id="phish-next-btn" style="
          margin-top:14px;width:100%;padding:12px;background:#2563EB;color:#fff;border:none;border-radius:6px;
          cursor:pointer;font-family:'Orbitron',sans-serif;font-size:13px;letter-spacing:1px;">
          NEXT EMAIL →
        </button>` : ''}
    `;

    reader.querySelector('#phish-safe-btn')?.addEventListener('click', () => this.answer(false));
    reader.querySelector('#phish-phish-btn')?.addEventListener('click', () => this.answer(true));
    reader.querySelector('#phish-next-btn')?.addEventListener('click', () => this.goNext());
  }

  private answer(saysPhishing: boolean): void {
    const s = this.emails[this.selectedIndex];
    if (!s || s.answered) return;
    const correct = saysPhishing === s.email.isPhishing;
    s.answered = true;
    s.correct = correct;

    if (correct) {
      GameManager.markCorrect(10);
      AudioManager.playSFX('correct');
      this.flash(0x22c55e);
    } else {
      const penalty = this.difficulty === 'easy' ? 0 : this.difficulty === 'hard' ? 10 : 5;
      GameManager.markWrong(penalty);
      AudioManager.playSFX('wrong');
      this.flash(0xef4444);
    }

    EventBus.emit('scoreUpdate', { score: GameManager.state.currentScore, hintsRemaining: GameManager.state.hintsRemaining });

    this.renderInbox();
    this.renderEmail();
    this.updateHeader();

    if (this.emails.every(em => em.answered)) {
      this.time.delayedCall(1200, () => this.finishLevel());
    }
  }

  private goNext(): void {
    // Find next unanswered email after current
    const total = this.emails.length;
    for (let i = 1; i <= total; i++) {
      const idx = (this.selectedIndex + i) % total;
      if (!this.emails[idx].answered) {
        this.selectedIndex = idx;
        break;
      }
    }
    this.renderInbox();
    this.renderEmail();
  }

  private handleHintRequest(): void {
    const s = this.emails[this.selectedIndex];
    if (!s || s.answered) return;
    if (!GameManager.useHint()) return;
    AudioManager.playSFX('hint');
    const root = this.dom.node as HTMLElement;
    const reader = root.querySelector('#phish-reader') as HTMLElement;
    const hintBox = document.createElement('div');
    const hint = s.email.isPhishing
      ? `🔍 HINT: Inspect the sender domain carefully — does it match the real organization?`
      : `🔍 HINT: The sender appears legitimate. Check tone, urgency, and links.`;
    hintBox.style.cssText = 'margin-top:12px;padding:10px;border:1px dashed #2563EB;border-radius:6px;color:#93C5FD;font-size:13px;';
    hintBox.textContent = hint;
    reader.appendChild(hintBox);
    this.updateHeader();
    EventBus.emit('scoreUpdate', { score: GameManager.state.currentScore, hintsRemaining: GameManager.state.hintsRemaining });
  }

  private updateHeader(): void {
    const root = this.dom.node as HTMLElement;
    const mm = Math.floor(this.timeLeft / 60);
    const ss = this.timeLeft % 60;
    (root.querySelector('#phish-timer') as HTMLElement).textContent = `${mm}:${String(ss).padStart(2, '0')}`;
    (root.querySelector('#phish-score') as HTMLElement).textContent = String(GameManager.state.currentScore);
    (root.querySelector('#phish-hints') as HTMLElement).textContent = String(GameManager.state.hintsRemaining);
    const answered = this.emails.filter(e => e.answered).length;
    (root.querySelector('#phish-progress') as HTMLElement).textContent = `${answered}/${this.emails.length}`;
  }

  private flash(color: number): void {
    this.flashOverlay.setFillStyle(color, 0.35);
    this.tweens.add({
      targets: this.flashOverlay,
      fillAlpha: 0,
      duration: 400,
      ease: 'Cubic.easeOut'
    });
  }

  private finishLevel(): void {
    this.timerEvent.remove();
    const learningPoints = [
      'Always inspect the sender domain — attackers use look-alikes like amaz0n.com or microsft.com.',
      'Urgency, threats, and deadlines are classic phishing pressure tactics.',
      'Never share OTPs, SSNs, or banking info via email — no real institution requests them this way.',
      'Hover over links before clicking. Shortened URLs and HTTP links in security emails are red flags.'
    ];
    const result = GameManager.finalize(learningPoints);
    AudioManager.playSFX(result.stars > 0 ? 'win' : 'lose');
    EventBus.emit('levelComplete', result);
  }

  private escape(s: string): string {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
}
