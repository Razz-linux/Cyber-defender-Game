import Phaser from 'phaser';
import { EventBus } from '../EventBus';
import { GameManager } from '../../services/GameManager';
import { AudioManager } from '../../services/AudioManager';
import { SaveManager } from '../../services/SaveManager';
import { passwords, calculatePasswordScore, strengthFromScore } from '../../data/passwords';
import type { PasswordEntry } from '../../types';

interface AuditState {
  entry: PasswordEntry;
  answered: boolean;
  correct: boolean | null;
}

export class PasswordScene extends Phaser.Scene {
  private dom!: Phaser.GameObjects.DOMElement;
  private audit: AuditState[] = [];
  private auditIndex = 0;
  private difficulty: 'easy' | 'normal' | 'hard' = 'normal';
  private phase: 'audit' | 'builder' = 'audit';
  private builderStartTime = 0;

  constructor() { super('PasswordScene'); }

  create(): void {
    GameManager.reset(2);
    this.difficulty = SaveManager.loadProgress().settings.difficulty;

    // Pick 10 passwords with mixed strengths
    const weakPool = passwords.filter(p => p.strength === 'weak');
    const medPool = passwords.filter(p => p.strength === 'medium');
    const strongPool = passwords.filter(p => p.strength === 'strong');
    const pick = (pool: PasswordEntry[], n: number) =>
      [...pool].sort(() => Math.random() - 0.5).slice(0, n);
    const selection = [...pick(weakPool, 4), ...pick(medPool, 3), ...pick(strongPool, 3)]
      .sort(() => Math.random() - 0.5);
    this.audit = selection.map(entry => ({ entry, answered: false, correct: null }));

    this.cameras.main.setBackgroundColor('#0B1020');
    const { width, height } = this.scale;
    this.dom = this.add.dom(width / 2, height / 2).createFromHTML(this.buildHTML());
    this.dom.setOrigin(0.5);

    this.bindHeader();
    this.renderAudit();
    this.updateHeader();

    EventBus.emit('sceneReady', { level: 2 });
    EventBus.on('hintRequest', this.handleHintRequest, this);
    this.events.on(Phaser.Scenes.Events.SHUTDOWN, () => {
      EventBus.off('hintRequest', this.handleHintRequest, this);
    });
  }

  private buildHTML(): string {
    const { width, height } = this.scale;
    return `
<div id="pw-root" style="
  width:${width - 40}px;height:${height - 40}px;
  background:#0F172A;border:1px solid #334155;border-radius:10px;
  display:grid;grid-template-rows:54px 1fr;font-family:Inter,sans-serif;color:#fff;overflow:hidden;
">
  <div style="background:#1E293B;border-bottom:1px solid #334155;padding:0 16px;display:flex;align-items:center;justify-content:space-between;">
    <div style="display:flex;align-items:center;gap:10px;">
      <div style="width:10px;height:10px;background:#22C55E;border-radius:50%;box-shadow:0 0 8px #22C55E;"></div>
      <div style="font-family:'Orbitron',sans-serif;font-size:14px;color:#94A3B8;letter-spacing:1px;">
        PASSWORD AUDIT TERMINAL — MISSION 2 / 3
      </div>
    </div>
    <div style="display:flex;align-items:center;gap:20px;font-family:'JetBrains Mono',monospace;font-size:13px;">
      <div>PHASE: <span id="pw-phase" style="color:#FACC15;">AUDIT</span></div>
      <div>SCORE: <span id="pw-score" style="color:#22C55E;">0</span></div>
      <div>HINTS: <span id="pw-hints" style="color:#2563EB;">3</span></div>
      <div>PROGRESS: <span id="pw-progress">0/10</span></div>
      <button id="pw-hint-btn" style="background:#2563EB;color:#fff;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;font-family:'Orbitron',sans-serif;font-size:11px;">💡 HINT (-10)</button>
    </div>
  </div>
  <div id="pw-body" style="padding:24px;overflow-y:auto;"></div>
</div>
`;
  }

  private bindHeader(): void {
    const root = this.dom.node as HTMLElement;
    root.querySelector('#pw-hint-btn')?.addEventListener('click', () => this.handleHintRequest());
  }

  private renderAudit(): void {
    const root = this.dom.node as HTMLElement;
    const body = root.querySelector('#pw-body') as HTMLElement;
    const state = this.audit[this.auditIndex];
    if (!state) return;
    const entry = state.entry;

    const meterScore = calculatePasswordScore(entry.password);
    const meterStrength = strengthFromScore(meterScore);
    const meterColor = meterStrength === 'weak' ? '#EF4444' : meterStrength === 'medium' ? '#FACC15' : '#22C55E';

    body.innerHTML = `
<div style="max-width:800px;margin:0 auto;">
  <div style="font-family:'Orbitron',sans-serif;font-size:18px;color:#2563EB;letter-spacing:2px;margin-bottom:8px;">
    PART A — PASSWORD AUDIT
  </div>
  <div style="color:#94A3B8;font-size:13px;margin-bottom:20px;">
    Audit each password from the team. Classify it as WEAK or STRONG.
  </div>

  <div style="background:#1E293B;border:1px solid #334155;border-radius:10px;padding:24px;">
    <div style="font-size:12px;color:#94A3B8;text-transform:uppercase;letter-spacing:2px;margin-bottom:8px;">
      Password #${this.auditIndex + 1} of ${this.audit.length}
    </div>
    <div style="font-family:'JetBrains Mono',monospace;font-size:32px;color:#fff;letter-spacing:2px;
        background:#0B1020;padding:18px 22px;border-radius:8px;border:1px solid #334155;word-break:break-all;">
      ${this.escape(entry.password)}
    </div>

    <div style="margin-top:20px;">
      <div style="font-size:12px;color:#94A3B8;margin-bottom:6px;">STRENGTH METER (live analysis)</div>
      <div style="height:14px;background:#0B1020;border-radius:7px;border:1px solid #334155;overflow:hidden;">
        <div id="pw-meter" style="height:100%;width:${meterScore}%;background:${meterColor};transition:width .35s,background .35s;"></div>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:12px;margin-top:6px;color:#94A3B8;">
        <span>Score: <strong style="color:${meterColor};">${meterScore}/100</strong></span>
        <span>Length: ${entry.password.length}</span>
        <span>Uppercase: ${/[A-Z]/.test(entry.password) ? '✓' : '✗'}</span>
        <span>Numbers: ${/[0-9]/.test(entry.password) ? '✓' : '✗'}</span>
        <span>Special: ${/[^A-Za-z0-9]/.test(entry.password) ? '✓' : '✗'}</span>
      </div>
    </div>

    ${state.answered ? `
      <div style="margin-top:18px;padding:14px;border-radius:8px;background:${state.correct ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)'};border:1px solid ${state.correct ? '#22C55E' : '#EF4444'};">
        <strong style="color:${state.correct ? '#22C55E' : '#EF4444'};">
          ${state.correct ? '✓ CORRECT' : '✗ WRONG'} — This password is ${entry.strength.toUpperCase()}.
        </strong>
        <div style="margin-top:6px;color:#cbd5e1;font-size:13px;">${this.escape(entry.feedback)}</div>
        <div style="margin-top:4px;color:#94A3B8;font-size:12px;">Estimated brute-force crack time: <strong style="color:#FACC15;">${this.escape(entry.crackTime)}</strong></div>
      </div>
    ` : ''}

    <div style="display:flex;gap:12px;margin-top:18px;">
      <button id="pw-weak" ${state.answered ? 'disabled' : ''} style="
        flex:1;padding:14px;background:${state.answered ? '#475569' : '#EF4444'};color:#fff;border:none;border-radius:6px;
        cursor:${state.answered ? 'not-allowed' : 'pointer'};font-family:'Orbitron',sans-serif;font-size:13px;letter-spacing:1px;font-weight:700;">
        ⚠ WEAK
      </button>
      <button id="pw-medium" ${state.answered ? 'disabled' : ''} style="
        flex:1;padding:14px;background:${state.answered ? '#475569' : '#FACC15'};color:#0B1020;border:none;border-radius:6px;
        cursor:${state.answered ? 'not-allowed' : 'pointer'};font-family:'Orbitron',sans-serif;font-size:13px;letter-spacing:1px;font-weight:700;">
        ⚡ MEDIUM
      </button>
      <button id="pw-strong" ${state.answered ? 'disabled' : ''} style="
        flex:1;padding:14px;background:${state.answered ? '#475569' : '#22C55E'};color:#fff;border:none;border-radius:6px;
        cursor:${state.answered ? 'not-allowed' : 'pointer'};font-family:'Orbitron',sans-serif;font-size:13px;letter-spacing:1px;font-weight:700;">
        ✓ STRONG
      </button>
    </div>

    ${state.answered ? `
      <button id="pw-next" style="
        margin-top:14px;width:100%;padding:12px;background:#2563EB;color:#fff;border:none;border-radius:6px;
        cursor:pointer;font-family:'Orbitron',sans-serif;font-size:13px;letter-spacing:1px;">
        ${this.auditIndex < this.audit.length - 1 ? 'NEXT PASSWORD →' : 'CONTINUE TO PART B →'}
      </button>` : ''}
  </div>
</div>
`;

    body.querySelector('#pw-weak')?.addEventListener('click', () => this.answerAudit('weak'));
    body.querySelector('#pw-medium')?.addEventListener('click', () => this.answerAudit('medium'));
    body.querySelector('#pw-strong')?.addEventListener('click', () => this.answerAudit('strong'));
    body.querySelector('#pw-next')?.addEventListener('click', () => this.nextAudit());
  }

  private answerAudit(label: 'weak' | 'medium' | 'strong'): void {
    const s = this.audit[this.auditIndex];
    if (!s || s.answered) return;
    const correct = label === s.entry.strength;
    s.answered = true;
    s.correct = correct;
    if (correct) {
      GameManager.markCorrect(7); // 7 points * 10 audits = 70 max, leaves 30 for builder
      AudioManager.playSFX('correct');
    } else {
      const penalty = this.difficulty === 'easy' ? 0 : this.difficulty === 'hard' ? 8 : 4;
      GameManager.markWrong(penalty);
      AudioManager.playSFX('wrong');
    }
    EventBus.emit('scoreUpdate', { score: GameManager.state.currentScore, hintsRemaining: GameManager.state.hintsRemaining });
    this.renderAudit();
    this.updateHeader();
  }

  private nextAudit(): void {
    if (this.auditIndex < this.audit.length - 1) {
      this.auditIndex += 1;
      this.renderAudit();
    } else {
      this.phase = 'builder';
      this.builderStartTime = Date.now();
      this.renderBuilder('');
      this.updateHeader();
    }
  }

  private renderBuilder(currentValue: string): void {
    const root = this.dom.node as HTMLElement;
    const body = root.querySelector('#pw-body') as HTMLElement;
    const score = calculatePasswordScore(currentValue);
    const strength = strengthFromScore(score);
    const color = strength === 'weak' ? '#EF4444' : strength === 'medium' ? '#FACC15' : '#22C55E';

    const checks = [
      { label: '12+ characters', ok: currentValue.length >= 12 },
      { label: '16+ characters (bonus)', ok: currentValue.length >= 16 },
      { label: 'Uppercase letters', ok: /[A-Z]/.test(currentValue) },
      { label: 'Lowercase letters', ok: /[a-z]/.test(currentValue) },
      { label: 'Numbers', ok: /[0-9]/.test(currentValue) },
      { label: 'Special characters', ok: /[^A-Za-z0-9]/.test(currentValue) },
      { label: 'No common patterns', ok: !/^(password|admin|qwerty|12345|111111|abc123)/i.test(currentValue) && !!currentValue },
      { label: 'No sequential chars', ok: !/(?:1234|abcd|qwer)/i.test(currentValue) }
    ];

    body.innerHTML = `
<div style="max-width:800px;margin:0 auto;">
  <div style="font-family:'Orbitron',sans-serif;font-size:18px;color:#2563EB;letter-spacing:2px;margin-bottom:8px;">
    PART B — PASSWORD BUILDER
  </div>
  <div style="color:#94A3B8;font-size:13px;margin-bottom:20px;">
    Design a STRONG password (score ≥ 70). Reach the threshold to complete the mission.
  </div>

  <div style="background:#1E293B;border:1px solid #334155;border-radius:10px;padding:24px;">
    <label style="font-size:12px;color:#94A3B8;text-transform:uppercase;letter-spacing:2px;">Enter Password</label>
    <input id="pw-input" value="${this.escape(currentValue)}" autocomplete="off" spellcheck="false" style="
      width:100%;margin-top:8px;padding:14px 16px;background:#0B1020;color:#fff;
      border:1px solid #334155;border-radius:8px;font-family:'JetBrains Mono',monospace;font-size:20px;
      letter-spacing:1px;outline:none;" />

    <div style="margin-top:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <span style="font-size:12px;color:#94A3B8;">STRENGTH</span>
        <span style="font-family:'Orbitron',sans-serif;font-size:14px;color:${color};letter-spacing:1px;">${strength.toUpperCase()} — ${score}/100</span>
      </div>
      <div style="height:14px;background:#0B1020;border-radius:7px;border:1px solid #334155;overflow:hidden;">
        <div style="height:100%;width:${score}%;background:${color};transition:width .3s,background .3s;"></div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:18px;">
      ${checks.map(c => `
        <div style="padding:8px 12px;background:#0B1020;border:1px solid #334155;border-radius:6px;font-size:13px;color:${c.ok ? '#22C55E' : '#94A3B8'};">
          ${c.ok ? '✓' : '○'} ${c.label}
        </div>
      `).join('')}
    </div>

    <button id="pw-submit" ${score < 70 ? 'disabled' : ''} style="
      margin-top:18px;width:100%;padding:14px;background:${score < 70 ? '#475569' : '#22C55E'};
      color:#fff;border:none;border-radius:8px;cursor:${score < 70 ? 'not-allowed' : 'pointer'};
      font-family:'Orbitron',sans-serif;font-size:14px;letter-spacing:1px;font-weight:700;">
      ${score < 70 ? `KEEP IMPROVING (need ${70 - score} more points)` : '✓ SUBMIT STRONG PASSWORD'}
    </button>
  </div>
</div>
`;

    const input = body.querySelector('#pw-input') as HTMLInputElement;
    input.focus();
    input.setSelectionRange(currentValue.length, currentValue.length);
    input.addEventListener('input', e => {
      const v = (e.target as HTMLInputElement).value;
      this.renderBuilder(v);
    });
    body.querySelector('#pw-submit')?.addEventListener('click', () => {
      const v = (body.querySelector('#pw-input') as HTMLInputElement).value;
      const s = calculatePasswordScore(v);
      if (s < 70) return;
      this.completeBuilder(s);
    });
  }

  private completeBuilder(builderScore: number): void {
    // Award up to 30 bonus points for builder, scaled with how strong + how fast
    const elapsed = (Date.now() - this.builderStartTime) / 1000;
    let timeBonus = 0;
    if (elapsed < 30) timeBonus = 10;
    else if (elapsed < 60) timeBonus = 5;
    const strengthBonus = builderScore >= 90 ? 20 : 15;
    const total = Math.min(30, strengthBonus + timeBonus);
    GameManager.addScore(total);
    GameManager.state.correct += 1;
    AudioManager.playSFX('win');
    EventBus.emit('scoreUpdate', { score: GameManager.state.currentScore, hintsRemaining: GameManager.state.hintsRemaining });
    this.finishLevel();
  }

  private handleHintRequest(): void {
    if (!GameManager.useHint()) return;
    AudioManager.playSFX('hint');

    const root = this.dom.node as HTMLElement;
    const body = root.querySelector('#pw-body') as HTMLElement;
    const hintBox = document.createElement('div');
    hintBox.style.cssText = 'max-width:800px;margin:14px auto 0;padding:12px;border:1px dashed #2563EB;border-radius:6px;color:#93C5FD;font-size:13px;';
    if (this.phase === 'audit') {
      const s = this.audit[this.auditIndex];
      hintBox.textContent = `🔍 HINT: This password is rated "${s.entry.strength.toUpperCase()}" by the security team. Look at length, character variety, and common-word usage.`;
    } else {
      hintBox.textContent = `🔍 HINT: Try at least 16 chars combining UPPER, lower, 0-9, and !@#$. Mix unrelated words like Mango!Tree$River#42.`;
    }
    body.appendChild(hintBox);
    this.updateHeader();
    EventBus.emit('scoreUpdate', { score: GameManager.state.currentScore, hintsRemaining: GameManager.state.hintsRemaining });
  }

  private updateHeader(): void {
    const root = this.dom.node as HTMLElement;
    (root.querySelector('#pw-score') as HTMLElement).textContent = String(GameManager.state.currentScore);
    (root.querySelector('#pw-hints') as HTMLElement).textContent = String(GameManager.state.hintsRemaining);
    (root.querySelector('#pw-phase') as HTMLElement).textContent = this.phase === 'audit' ? 'AUDIT' : 'BUILDER';
    const answered = this.audit.filter(a => a.answered).length;
    (root.querySelector('#pw-progress') as HTMLElement).textContent =
      this.phase === 'audit' ? `${answered}/${this.audit.length}` : 'BUILDER';
  }

  private finishLevel(): void {
    const learningPoints = [
      'Length beats complexity — 16+ random characters are exponentially harder to crack.',
      'Avoid dictionary words, names, dates, and keyboard patterns like qwerty or 123456.',
      'Mix uppercase, lowercase, numbers, and special characters to maximize entropy.',
      'Use a password manager so every account can have a unique, strong password.'
    ];
    const result = GameManager.finalize(learningPoints);
    AudioManager.playSFX(result.stars > 0 ? 'win' : 'lose');
    EventBus.emit('levelComplete', result);
  }

  private escape(s: string): string {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
}
