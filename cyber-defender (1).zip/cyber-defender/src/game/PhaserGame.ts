import Phaser from 'phaser';
import { BootScene } from './scenes/BootScene';
import { PhishingScene } from './scenes/PhishingScene';
import { PasswordScene } from './scenes/PasswordScene';
import { MalwareScene } from './scenes/MalwareScene';

export function createPhaserGame(parent: HTMLElement, level: number): Phaser.Game {
  const width = Math.min(1280, parent.clientWidth || 1100);
  const height = Math.min(720, Math.max(560, parent.clientHeight || 640));

  const config: Phaser.Types.Core.GameConfig = {
    type: Phaser.AUTO,
    parent,
    width,
    height,
    backgroundColor: '#0B1020',
    scale: {
      mode: Phaser.Scale.FIT,
      autoCenter: Phaser.Scale.CENTER_BOTH
    },
    dom: { createContainer: true },
    scene: [BootScene, PhishingScene, PasswordScene, MalwareScene],
    physics: { default: 'arcade' },
    render: { antialias: true, pixelArt: false }
  };

  const game = new Phaser.Game(config);
  game.registry.set('level', level);
  return game;
}
